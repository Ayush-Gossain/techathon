from flask import Flask,jsonify,request, stream_with_context, Response
from pymongo import MongoClient
from flask_cors import CORS
import json
from bson.json_util import dumps
from datetime import datetime, timedelta
from gridfs import GridFS
import os
import random
import string
import base64
import filetype
import time

app = Flask(__name__)
CORS(app)
policy_id_counter = 1

client = MongoClient('mongodb+srv://gossainayush:FZYWx7RKRC61g1F3@cluster0.69hnw.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0')
db = client['iqGenie']
fs = GridFS(db)

# Base directory for file storage
UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
















database = client["iqGenie"]

# Define the collections used in the application.
agents_collection = database.get_collection("Agent")
models_collection = database.get_collection("Model")
workflows_collection = database.get_collection("Workflow")
general_model = database.get_collection("GeneralModel")
genai_model = database.get_collection("GenAIModel")
knowledge_graph = database.get_collection("KnowledgeGraph")
selected_workflow_collection = database.get_collection("SelectedWorkflow")

# GET /api/sidebarWorkflows
@app.route('/api/sidebarWorkflows', methods=['GET'])
def get_sidebar_workflows():
    workflows = workflows_collection.find({}, {"_id": 0, "workflow_id": 1, "Name": 1, "executable": 1})
    result = [{"id": wf["workflow_id"], "name": wf["Name"], "executable": wf["executable"]} for wf in workflows]
    return jsonify(result)

# GET /api/sidebarAgents
@app.route('/api/sidebarAgents', methods=['GET'])
def get_sidebar_agents():
    agents = agents_collection.find({}, {"_id": 0, "agent_id": 1, "name": 1, "disabled": 1})
    result = [{"id": ag["agent_id"], "name": ag["name"], "disabled": ag["disabled"]} for ag in agents]
    return jsonify(result)

# GET /api/sidebarGenaimodels
@app.route('/api/sidebarGenaimodels', methods=['GET'])
def get_sidebar_genaimodels():
    genaimodels = genai_model.find({}, {"_id": 0, "model_id": 1, "model_name": 1, "active": 1})
    result = [{"id": gm["model_id"], "name": gm["model_name"], "active": gm["active"]} for gm in genaimodels]
    return jsonify(result)

# GET /api/sidebarGeneralmodels
@app.route('/api/sidebarGeneralmodels', methods=['GET'])
def get_sidebar_generalmodels():
    generalmodels = general_model.find({}, {"_id": 0, "model_id": 1, "name": 1, "active": 1})
    result = [{"id": gm["model_id"], "name": gm["name"], "active": gm["active"]} for gm in generalmodels]
    return jsonify(result)

# GET /api/KnowledgeGraph
@app.route('/api/KnowledgeGraph', methods=['GET'])
def get_knowledge_graph():
    knowledge_graphs = knowledge_graph.find({}, {"_id": 0, "kg_id": 1, "name": 1, "active": 1})
    result = [{"id": kg["kg_id"], "name": kg["name"], "active": kg["active"]} for kg in knowledge_graphs]
    return jsonify(result)

# GET /api/canvasNodes
@app.route('/api/canvasNodes', methods=['GET'])
def get_canvas_nodes():
    workflow_id = request.args.get('workflow_id')
    workflow = workflows_collection.find_one({"workflow_id": workflow_id}, {"_id": 0, "nodes": 1})
    if not workflow:
        return jsonify([])
    nodes = workflow.get("nodes", [])
    result = [
        {
            "id": node["id"],
            "type": node["type"],
            "position": node["position"],
            "data": {
                "label": node["data"]["label"],
                "nodeType": node["data"]["nodeType"],
                "showInput": node["data"].get("showInput", True),
                "showOutput": node["data"].get("showOutput", True)
            }
        }
        for node in nodes
    ]
    return jsonify(result)

# GET /api/canvasEdges
@app.route('/api/canvasEdges', methods=['GET'])
def get_canvas_edges():
    workflow_id = request.args.get('workflow_id')
    workflow = workflows_collection.find_one({"workflow_id": workflow_id}, {"_id": 0, "edges": 1})
    if not workflow:
        return jsonify([])
    edges = workflow.get("edges", [])
    result = [{"id": edge["id"], "source": edge["source"], "target": edge["target"]} for edge in edges if edge["source"] !="START"]
    return jsonify(result)

# POST /api/useWorkflow
@app.route('/api/useWorkflow', methods=['POST'])
def use_workflow():
    data = request.get_json()
    workflow_id = data.get("workflowId")

    # Fetch the workflow from the Workflow collection
    workflow = workflows_collection.find_one({"workflow_id": workflow_id})
    if not workflow:
        return jsonify({"error": "Workflow not found."}), 404

    purpose = workflow.get("Description", "")

    # Check if the same workflow_id and purpose already exist
    existing_workflow = selected_workflow_collection.find_one({"workflow_id": workflow_id, "Description": purpose})
    if existing_workflow:
        return jsonify({"message": "Workflow already exists."}), 200

    # Check for a different workflow_id with the same purpose
    selected_workflow_collection.delete_many({"Description": purpose, "workflow_id": {"$ne": workflow_id}})

    # Insert the new workflow into SelectedWorkflow
    workflow_copy = {k: v for k, v in workflow.items() if k != "_id"}
    selected_workflow_collection.insert_one(workflow_copy)

    return jsonify({"message": "Workflow saved successfully."}), 201

# GET /api/currentWorkflow
@app.route('/api/currentWorkflow', methods=['GET'])
def current_workflow():
    current_workflow = selected_workflow_collection.find_one({}, {"_id": 0})
    if not current_workflow:
        return jsonify({"message": "No current workflow found."}), 404
    return jsonify(current_workflow)




def get_last_7_days():
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=7)
    return start_date, end_date

@app.route('/frequency_of_claim', methods=['GET'])
def frequency_of_claim():
    start_date, end_date = get_last_7_days()
    pipeline = [
        {"$match": {"claim_date": {"$gte": start_date, "$lt": end_date}}},
        {"$group": {"_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$claim_date"}}, "count": {"$sum": 1}}},
        {"$sort": {"_id": 1}}
    ]
    result = list(db.Claim.aggregate(pipeline))
    labels = [x['_id'] for x in result]
    data = [x['count'] for x in result]
    return jsonify({"labels": labels, "data": data})

@app.route('/fraud_vs_non_fraud', methods=['GET'])
def fraud_vs_non_fraud():
    start_date, end_date = get_last_7_days()
    pipeline = [
        {"$match": {"claim_date": {"$gte": start_date, "$lt": end_date}}},
        {"$group": {"_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$claim_date"}}, "fraud": {"$sum": {"$cond": ["$is_fraud", 1, 0]}}, "non_fraud": {"$sum": {"$cond": ["$is_fraud", 0, 1]}}}},
        {"$sort": {"_id": 1}}
    ]
    result = list(db.Claim.aggregate(pipeline))
    labels = [x['_id'] for x in result]
    fraud_data = [x['fraud'] for x in result]
    non_fraud_data = [x['non_fraud'] for x in result]
    return jsonify({"labels": labels, "fraud_data": fraud_data, "non_fraud_data": non_fraud_data})

@app.route('/claim_accept_vs_reject', methods=['GET'])
def claim_accept_vs_reject():
    start_date, end_date = get_last_7_days()
    pipeline = [
        {"$match": {"claim_date": {"$gte": start_date, "$lt": end_date}}},
        {"$group": {"_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$claim_date"}}, "accepted": {"$sum": {"$cond": [{"$eq": ["$status", "Accepted"]}, 1, 0]}}, "rejected": {"$sum": {"$cond": [{"$eq": ["$status", "Rejected"]}, 1, 0]}}}},
        {"$sort": {"_id": 1}}
    ]
    result = list(db.Claim.aggregate(pipeline))
    labels = [x['_id'] for x in result]
    accepted_data = [x['accepted'] for x in result]
    rejected_data = [x['rejected'] for x in result]
    return jsonify({"labels": labels, "accepted_data": accepted_data, "rejected_data": rejected_data})
























































def generate_unique_claim_id():
   while True:
       claim_id = "CL_" + ''.join(random.choices(string.digits, k=8))
       if not db.Claim.find_one({"claim_id": claim_id}):
           return claim_id

def save_base64_file(base_dir, file, file_name):
   os.makedirs(base_dir, exist_ok=True)
   file_path = os.path.join(base_dir, file_name)
   with open(file_path, "wb") as f:
       f.write(base64.b64decode(file))
   return file_path


@app.route('/get_claims',methods=['get'])
def get_claims():
    try:
        claims = db.Claim.find()
        claims_json = dumps(claims)
        claims_json = json.loads(claims_json)
        
        return claims_json
    except Exception as e:
        return jsonify({'error':str(e)}),500

@app.route('/get_recent_claims',methods=['get'])
def get_recent_claims():
    try:
        claims = db.Claim.find({'status':'unknown'})
        claims_json = dumps(claims)
        claims_json = json.loads(claims_json)
        
        return claims_json
    except Exception as e:
        return jsonify({'error':str(e)}),500
    
@app.route('/diag_dropdown_data',methods=['get'])
def client_dropdown_data():
    try:
        Diag = db.Diagnosis.find()
        
        Diag_json = dumps(Diag)
        Diag_json = json.loads(Diag_json)
        
        
        return Diag_json
        # return Diag_json, Hos_json, Doc_json
    except Exception as e:
        return jsonify({'error':str(e)}),500

@app.route('/hos_dropdown_data',methods=['get'])
def hos_dropdown_data():
    try:
        # Diag = db.Diagnosis.find()
        Hos = db.Hospital.find()
        # Doc = db.Doctor.find()
       
        Hos_json = dumps(Hos)
        Hos_json = json.loads(Hos_json)
        
        
        return Hos_json
        # return Diag_json, Hos_json, Doc_json
    except Exception as e:
        return jsonify({'error':str(e)}),500

@app.route('/doc_dropdown_data',methods=['get'])
def doc_dropdown_data():
    try:
        
        Doc = db.Doctor.find()
        
        Doc_json = dumps(Doc)
        Doc_json = json.loads(Doc_json)
        
        return Doc_json
        # return Diag_json, Hos_json, Doc_json
    except Exception as e:
        return jsonify({'error':str(e)}),500








@app.route('/get_claim_details/<claim_id>', methods=['GET'])
def get_claim_details(claim_id):
    try:

        # Aggregation pipeline
        pipeline = [
            {
                "$match": {
                    "claim_id": claim_id  # Match the claim by claim_id
                }
            },
            # Lookup to join Policy collection
            {
                "$lookup": {
                    "from": "User",  # The collection to join
                    "localField": "policy_id",  # The field in Claim
                    "foreignField": "policy_id",  # The field in Policy
                    "as": "user_details"  # Alias for joined data
                }
            },
            # Lookup to join Hospital collection
            {
                "$lookup": {
                    "from": "Hospital",
                    "localField": "hospital_id",
                    "foreignField": "hospital_id",
                    "as": "hospital_details"
                }
            },
            # Lookup to join Doctor collection
            {
                "$lookup": {
                    "from": "Doctor",
                    "localField": "doctor_id",
                    "foreignField": "doctor_id",
                    "as": "doctor_details"
                }
            },
            # Lookup to join Diagnosis collection
            {
                "$lookup": {
                    "from": "Diagnosis",
                    "localField": "diagnosis_id",
                    "foreignField": "diagnosis_id",
                    "as": "diagnosis_details"
                }
            },
            # Projecting the necessary fields for the output
            {
                "$project": {
                    "_id": 0,  # Exclude _id field from the output
                    "claim_id": 1,
                    "claim_amount": 1,
                    "admitted_dates": 1,
                    "files":1,
                    "hospital_details": {
                        "hospital_name": 1,
                        "location": 1,
                        "latitude": 1,
                        "longitude": 1,
                        "criteria": 1,
                        "fraud_flag_count": 1,
                        "village_or_city": 1,
                        "hospital_type": 1
                    },
                    "doctor_details": {
                        "doctor_name": 1,
                        "experience_years": 1,
                        "fraud_flag_count": 1,
                        "doctor_type": 1
                    },
                    "diagnosis_details": {
                        "disease_name": 1,
                        "stay_days": 1,
                        "average_cost": 1
                    },
                    "user_details": {
                        "policy_id": 1,
                        "name": 1,
                        "age": 1,
                        "date_of_birth": 1,
                        "email": 1,
                        "policy": 1,

                    }
                }
            }
        ]

        # Run aggregation query
        result = db.Claim.aggregate(pipeline)

        # Convert result to a list and return as JSON
        claim_details = list(result)
        print(f'claim_details:{claim_details}')
        # if claim_details:
        #     claim = claim_details[0]
        #     response ={
        #         "claim_details": claim,
        #         "files": {}
        #     }
        #     for file_type, file_path in claim['files'].items():
        #         if os.path.exists(file_path):
        #             with open(file_path, 'rb') as file:
        #                 response['files'][file_type] = base64.b64decode(file.read()).decode('utf-8')
        #         else:
        #             response['files'][file_type] = None
        return jsonify(claim_details), 200
        # else:
        #     return jsonify({"error": "Claim not found"}), 404

    except Exception as e:
        print(str(e))
        return jsonify({"error": str(e)}), 500

@app.route('/store_claim', methods=['POST'])
def store_claim():
    claim_id = generate_unique_claim_id()
    hospitalname=request.form.get('hospital')
    docname=request.form.get('docname')
    diagname=request.form.get('diagname')
    description=request.form.get('desc')
    claimamount=request.form.get('claimamount')
    admitdate=request.form.get('admitdate')
    discharge=request.form.get('dischargedate')
    policyId = request.form.get('policyId')
    report=request.files['reportfile']
    bill=request.files['billfile']
    pres=request.files['presfile']
    pic = request.files['picfile']

    base_dir = os.path.join(UPLOAD_FOLDER, policyId, claim_id)

    medical_report_file = save_base64_file(base_dir, report.read(), f"{claim_id}_medical_report."+filetype.guess(report).extension)
    medical_prescription_file = save_base64_file(base_dir, pres.read(), f"{claim_id}_medical_prescription."+filetype.guess(pres).extension)
    medical_bill_file = save_base64_file(base_dir, bill.read(), f"{claim_id}_medical_bill."+filetype.guess(bill).extension)
    picture_file = save_base64_file(base_dir, pic.read(), f"{claim_id}_picture."+filetype.guess(pic).extension)

    # Insert into MongoDB
    claim_data = {
        "claim_id": claim_id,
        "policy_id": policyId,
        "hospital_id": hospitalname,
        "doctor_id": docname,
        "diagnosis_id": diagname,
        "claim_amount": claimamount,
        "claim_date": datetime.now(),
        "status": "unknown",
        "admitted_start_date": admitdate,
        "admitted_end_date": discharge,
        "description": description,
        "files": {
            "medical_report_file": medical_report_file,
            "medical_prescription_file": medical_prescription_file,
            "medical_bill_file": medical_bill_file,
            "picture_file": picture_file
        },
        "created_at": datetime.now(),
    }
    db.Claim.insert_one(claim_data)
    return jsonify({"message": "Claim submitted successfully", "claim_id": claim_id}), 201


def calculate_age(dob):
    today = datetime.now()
    age = today.year - dob.year
    return age
def generate_policy_id():
    global policy_id_counter
    new_policy_id = f"PL_{policy_id_counter:08d}"
    policy_id_counter += 1
    return new_policy_id

@app.route('/register', methods=[ 'POST'])
def register():
        data = request.get_json()
        print(f'data: {data} and type: {type(data)}')
    # if request.method == 'POST':h

        first = data.get('first')
        last = data.get('last')
        password = data.get('password')
        email = data.get('email')
        start_date = datetime.now()
        end_date = start_date + timedelta(days=2*365)
        date_of_birth = data.get('dob')
        dob = datetime.strptime(date_of_birth, '%Y-%m-%d')
        age = calculate_age(dob)
        policy_id = generate_policy_id()
        if db.User.find_one({'email': email}):
            # flash('Username already exists.')
            return {'message':'already exist'}
        new_user = {'policy_id':policy_id,'email':email,'name': {'first':first,'last':last},'date_of_birth':dob,'age':age,'policy':{'start_date':start_date,'end_date':end_date}, 'password': password}
        db.User.insert_one(new_user)
        # login_user(User(new_user))
        return {'message':'success'}
    # return render_template('register.html')

@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get('email', '')
    password = data.get('password', '')
    user_data = db.User.find_one({"policy_id": email})
    if not user_data:
            user_data = db.Admin.find_one({'email': email})
    if user_data and user_data['password'] == password:
        # login_user(User(user_data))
        return {'message':'success','type':user_data['type']}
    return {'message':'invalid email or password'}

@app.route('/dashboard', methods=['GET'])
def get_dashboard_stats():
    # Get count of all users 
    total_users = db.User.count_documents({})

    # Get count of all claims
    total_claims = db.Claim.count_documents({})

    # Get count of processed claims (claims that have a "status" field)
    processed_claims = db.Claim.count_documents({"status": {"$exists": True}})

    # Get count of rejected claims (status == "rejected")
    rejected_claims = db.Claim.count_documents({"status": "Rejected"})

    # Get count of accepted claims (status == "accepted"})
    accepted_claims = db.Claim.count_documents({"status": "Accepted"})

    # Prepare JSON response with counts
    response = {
        "total_users": total_users,
        "total_claims": total_claims,
        "processed_claims": processed_claims,
        "rejected_claims": rejected_claims,
        "accepted_claims": accepted_claims
    }

    return jsonify(response), 200


big_t = '''

Lorem ipsum dolor sit amet, consectetu. ibulum finibus, quam quis scelerisque vehicula, lacus lectus aliquam eros, at dignissim metus neque quis tellus. Nulla pulvinar fringilla sem. Ut nec sodales felis. Praesent et velit in felis hendrerit fermentum eget non lectus. Duis iaculis nunc libero, sed ullamcorper nisi volutpat in. Nam consectetur tempor lectus id commodo. Nulla blandit tincidunt libero, eget dignissim purus. Donec laoreet risus a metus feugiat condimentum. Aliquam rhoncus at lacus nec posuere. Nullam feugiat aliquam tristique. Donec porttitor elit in dolor tincidunt ullamcorper. Vivamus aliquam pharetra molestie. Phasellus iaculis sem id massa lacinia tincidunt. Ut at interdum massa. Pellentesque rhoncus pretium eros, sed vestibulum nulla blandit id.

'''.strip()

# Streaming generator function
def generate_text_stream(text, chunk_size=10):
    words = text.split()
    for i in range(0, len(words), chunk_size):
        chunk = " ".join(words[i:i + chunk_size])
        yield f"data: {chunk}\n\n"  # Send chunks in Server-Sent Events (SSE) format
        time.sleep(0.2)  # Simulate real-time typing effect

@app.route('/stream-text')
def stream_text():
    """Streams text in chunks"""
    return Response(stream_with_context(generate_text_stream(big_t, chunk_size=10)),
                    content_type='text/event-stream')


if __name__ == '__main__':
    app.run(debug=True)