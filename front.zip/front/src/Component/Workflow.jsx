import { useCallback, useState } from 'react';
import {
  ReactFlow,
  addEdge,
  applyEdgeChanges,
  applyNodeChanges,
  ReactFlowProvider,
  MiniMap,
  Controls,
  Background
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import '../Styles/Workflow.css'
 
import { initialNodes } from './nodes';
import { initialEdges } from './edges';
 
const rfStyle = {
  backgroundColor: '#f0f0f0; ',
};


const AgenticWorkflow = () => {
    const [nodes, setNodes] = useState(initialNodes);
    const [edges, setEdges] = useState(initialEdges);
   
    const onNodesChange = useCallback(
      (changes) => setNodes((nds) => applyNodeChanges(changes, nds)),
      [setNodes],
    );
    const onEdgesChange = useCallback(
      (changes) => setEdges((eds) => applyEdgeChanges(changes, eds)),
      [setEdges],
    );
    const onConnect = useCallback(
      (connection) => setEdges((eds) => addEdge(connection, eds)),
      [setEdges],
    );
   
    return (
      <div className="workflowContainer">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        fitView
        style={rfStyle}
        attributionPosition="top-right"
      > 
      {/* <MiniMap /> */}
      {/* <Controls /> */}
      {/* <Background color="#aaa" gap={16} /> */}
      </ReactFlow>
      </div>
    );
  };

const Workflow = () => {
    
  
    return (
        <ReactFlowProvider>
          <AgenticWorkflow />
        </ReactFlowProvider>
      );
}

export default Workflow
