import React,{useState,useEffect} from 'react'
import { useNavigate } from 'react-router-dom';
import '../Styles/Client.css'
import { useParams } from 'react-router-dom'
import Genie from './Genie';
import ReactMarkdown from 'react-markdown';

import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import Tooltip from '@mui/material/Tooltip';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';
// import Messages from 'layouts/AdminLayout/NavBar/NavRight/ChatList/Friends/Chat/Messages';

const Clienthome = () => {
  const  {policy_id} = useParams()
  const navigate = useNavigate()


  const [open, setOpen] = React.useState(false);
  const [msg,setMsg] = useState('')
  const [alert,setAlert] = useState('')
  const [openBackdrop, setOpenBackdrop] = React.useState(false);

    const [patientName, setPatientName] = useState('');
  const [hospitalName, setHospitalName] = useState([]);
  const [desc, setdesc] = useState('');
  const [diag, setdiag] = useState([]);
  const [doctor, setdoctor] = useState([]);
  

  const [finaldiag, setfinaldiag] = useState();
  const [finaldoc, setfinaldoc] = useState();
  const [finalhos, setfinalhos] = useState();

  const [uploadreport, setReport] = useState();
  const [uploadbill, setbill] = useState();
  const [pic, setpic] = useState();
  const [prescription, setprescription] = useState();

  const [firstname, setfirstname] = useState('');
  const [lastname, setlastname] = useState('');
  const [claimamount, setclaimamount] = useState('');
  const [admit, setadmit] = useState('');
  const [end, setend] = useState('');


  // const report = (e) => {
  //   const newFiles = Array.from(e.target.files);
  //   setReport((prevDocs) => [...prevDocs, ...newFiles]);
  //   // setDocuments([...e.target.files]);
  // };

  // const medicalbill = (e) => {
  //   const newFiles = Array.from(e.target.files);
  //   setbill((prevDocs) => [...prevDocs, ...newFiles]);
  //   // setDocuments([...e.target.files]);
  // };
  // const prescription = (e) => {
  //   const newFiles = Array.from(e.target.files);
  //   setDocuments((prevDocs) => [...prevDocs, ...newFiles]);
  //   // setDocuments([...e.target.files]);
  // };



  const handleDelete = (index) => {
    setDocuments((prevDocs) => prevDocs.filter((_, i) => i !== index));
  };

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
  }
  

  const handleSubmit = async(e) => {
    setOpenBackdrop(true)
    e.preventDefault();
    const formdata = new FormData()
    formdata.append('first_name',firstname)
    formdata.append('lastname',lastname)
    formdata.append('hospital',finalhos)
    formdata.append('docname',finaldoc)
    formdata.append('diagname',finaldiag)
    formdata.append('desc',desc)
    formdata.append('claimamount',claimamount)
    formdata.append('admitdate',admit)
    formdata.append('dischargedate',end)
    formdata.append('reportfile',uploadreport)
    formdata.append('billfile',uploadbill)
    formdata.append('picfile',pic)
    formdata.append('presfile',prescription)
    formdata.append('policyId',policy_id)

    try {
      await fetch(`http://127.0.0.1:5000/store_claim`,{
        method:"post",
        // headers:{
        //     "Content-Type":"application/json"
        // },
          body:formdata
        
        }).then(res=>res.json())
        .then(data=>{
          setAlert('success')
                setMsg('success')
                setOpenBackdrop(false)
          
            console.log(data)
            
           
        }).catch(err=>{
          console.log(err)
          setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
        })
      
    } catch (error) {
      alert('error',error)
      setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
      
    }
  };


  const getdocdata = async()=>{
    setOpenBackdrop(true)
    console.log('type called');
    try {
      await fetch(`http://127.0.0.1:5000/doc_dropdown_data`,{
        method:"get",
        // headers:{
        //   'Authorization': `Bearer ${token}`
        // }
        }).then(res=>res.json())
        .then(data=>{
          
            console.log(data)
            setdoctor(data)
            getdiagdata()
            setAlert('success')
                setMsg('success')
                setOpenBackdrop(false)
           
        }).catch(err=>{
          console.log(err)
          setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
        })
      
    } catch (error) {
      alert('error',error)
      setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
      
    }
  }

  const getdiagdata = async() =>{
    setOpenBackdrop(true)
    console.log('type called');
    try {
      await fetch(`http://127.0.0.1:5000/diag_dropdown_data`,{
        method:"get",
        // headers:{
        //   'Authorization': `Bearer ${token}`
        // }
        }).then(res=>res.json())
        .then(data=>{
          
            console.log(data)
            setdiag(data)
            setAlert('success')
                setMsg('success')
                setOpenBackdrop(false)
            // getdocdata()
           
        }).catch(err=>{
          console.log(err)
          setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
        })
      
    } catch (error) {
      alert('error',error)
      setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
      
    }
  }

  

  
  const first = () =>{
    if(window.localStorage.getItem('type')=='approver'){
      navigate('/admin')
    }else if(window.localStorage.getItem('type')=='developer'){
      navigate('/workflow')
      
    }else{
      get_dash_data()
    }
  }

  const get_dash_data = async() =>{
    console.log('type called');
    setOpenBackdrop(true)
    try {
      await fetch(`http://127.0.0.1:5000/hos_dropdown_data`,{
        method:"get",
        // headers:{
        //   'Authorization': `Bearer ${token}`
        // }
        }).then(res=>res.json())
        .then(data=>{
          
            console.log(data)
            setHospitalName(data)
            getdocdata()
            setAlert('success')
                setMsg('success')
                setOpenBackdrop(false)
           
        }).catch(err=>{
          console.log(err)
          setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
        })
      
    } catch (error) {
      alert('error',error)
      setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
      
    }
}


  useEffect(()=>{
              first()
            },[])

  const markdown = `
  **### What Our Application Does**
- Integrates Knowledge Graph, Vector RAG, Graph RAG, and advanced CNN-based Face Verification to deliver real-time insights and security.
- Harnesses quantum technology to proactively detect and mitigate fraud.
- Empowers you to create bespoke workflows using our Agentic AI framework—choose specific models, configure agents, and customize them to match your exact needs.

**### Purpose**
- To give businesses a secure, cutting-edge, and highly flexible environment where they can innovate faster, reduce risks, and remain AI-first in a rapidly evolving market.

**### Key Problems Solved**
- **Data Overload**: Transform fragmented data into meaningful intelligence with Knowledge Graph and RAG technologies.
- **Fraud Vulnerability**: Identify hidden threats through advanced CNN-based face verification and quantum-powered fraud detection.
- **Complex AI Adoption**: Simplify AI deployment by offering pre-built workflows and fully customizable agentic models.
`



  return (<>
  <Backdrop
        sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={openBackdrop}
        // onClick={handleClose}
      >
        <CircularProgress color="inherit" />
      </Backdrop>


      <Snackbar anchorOrigin={{ vertical: 'top', horizontal: 'right' }} open={open} autoHideDuration={5000} onClose={handleClose}>
        <Alert
          onClose={handleClose}
          severity={alert}
          variant="filled"
          sx={{ width: '100%' }}
        >
          {msg}
        </Alert>
      </Snackbar>








  <Genie/>
    <div className="mainbox">
        <div className="left">
        {/* <h2>Health Insurance Claim</h2> */}
        <div className="written">
          <ReactMarkdown>{markdown}</ReactMarkdown>
          </div>
        </div>
        <div className="form-container">
      <h2>Health Insurance Claim</h2>
      <form onSubmit={handleSubmit}>
        {/* <div className="form-group">
          <label>First Name:</label>
          <input
            type="text"
            value={firstname}
            className='name'
            placeholder='enter patients name here'
            onChange={(e) => setfirstname(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Last Name:</label>
          <input
            type="text"
            value={lastname}
            className='name'
            placeholder='enter patients name here'
            onChange={(e) => setlastname(e.target.value)}
            required
          />
        </div> */}
        <div className="form-group">
          <label>Hospital Name:</label>
          <select
                className='name'
                value={finalhos}
                onChange={(e)=>setfinalhos(e.target.value)}
                style={{}}>
                   <option value="someOption">--select--</option>
                   {
                    hospitalName && hospitalName.map((item,index)=>{
                      return <option value={item.hospital_id}>{item.hospital_name}</option>
                    })
                   }
    
                     
                    
            </select>
        </div>
        <div className="form-group">
          <label>Doctor's Name:</label>
          <select
                className='name'
                style={{}}
                value={finaldoc}
                onChange={(e)=>setfinaldoc(e.target.value)}>
                   <option value="someOption">--select--</option>
    
                   {
                    doctor && doctor.map((item,index)=>{
                      return <option value={item.doctor_id}>{item.name}</option>
                    })
                   }
                    
            </select>
        </div>
        <div className="form-group">
          <label>Type of Diagnosis:</label>
          <select
                className='name'
                value={finaldiag}
                onChange={(e)=>setfinaldiag(e.target.value)}
                style={{}}>
                   <option value="someOption">--select--</option>
    
                   {
                    diag && diag.map((item,index)=>{
                      
                      return <option value={item.diagnosis_id}>{item.disease_name}</option>
                    })
                   }
                    
            </select>
          {/* <input
            type="text"
            className='name'
            value={hospitalName}
            onChange={(e) => setHospitalName(e.target.value)}
            required
          /> */}
        </div>
        
        {/* <div className="form-group">
          <label>Deductible Paid:</label>
          <input
            type="number"
            className='name'
            value={hospitalName}
            onChange={(e) => setHospitalName(e.target.value)}
            required
          />
        </div> */}
        {/* <div className="form-group">
          <label>Claim Id:</label>
          <input
            type="number"
            className='name'
            value={hospitalName}
            onChange={(e) => setHospitalName(e.target.value)}
            required
          />
        </div> */}


        {/* <div className="flex">
        <div className="form-group">
          <label>Start Date:</label>
          <input
            type="date"
            className='name'
            value={hospitalName}
            onChange={(e) => setHospitalName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>End Date:</label>
          <input
            type="date"
            className='name'
            value={hospitalName}
            onChange={(e) => setHospitalName(e.target.value)}
            required
          />
        </div>
        </div> */}



        <div className="form-group">
          <label>Description:</label>
          <input
            type="text"
            className='name'
            placeholder='enter description of your diagnosis'
            value={desc}
            onChange={(e) => setdesc(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Claim Amount:</label>
          <input
            type="number"
            className='name'
            value={claimamount}
            onChange={(e) => setclaimamount(e.target.value)}
            required
          />
        </div>


        <div className="flex">

        <div className="form-group">
          <label>Admitted Date:</label>
          <input
            type="date"
            className='name'
            value={admit}
            onChange={(e) => setadmit(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <label>Discharge Date:</label>
          <input
            type="date"
            className='name'
            value={end}
            onChange={(e) => setend(e.target.value)}
            required
          />
        </div>
        </div>


        <div className="flex">
        <div className="insidesection">
          <p>Upload Medical Report:</p>
          <input
            type="file"
            // className='name'
            // multiple
            onChange={(e)=>setReport(e.target.files[0])}
            required
          />
        </div>
        <div className="insidesection">
          <p>Upload Prescription:</p>
          <input
            type="file"
            // className='name'
            // multiple
            onChange={(e)=>setprescription(e.target.files[0])}
            required
          />
        </div>
        </div>
        
        <div className="flex">
        <div className="insidesection">
          <p>Upload Medical Bill :</p>
          <input
            type="file"
            // className='name'
            // multiple
            onChange={(e)=>setbill(e.target.files[0])}
            required
          />
        </div>
        <div className="insidesection">
          <p>Upload Your Recent Picture :</p>
          <input
            type="file"
            // className='name'
            // multiple
            onChange={(e)=>setpic(e.target.files[0])}
            required
          />
        </div>
        {/* <div className="insidesection">
          <p>Upload Your KYC Document:</p>
          <input
            type="file"
            className='name'
            multiple
            onChange={handleFileChange}
            required
          />
        </div> */}
        </div>
        
        {/* <div className="insidesection">
          <p>Upload Recent pic:</p>
          <input
            type="file"
            className='name'
            multiple
            onChange={handleFileChange}
            required
          />
          
        </div> */}
        {/* <div className="file-list">
          {documents.map((file, index) => (
            <div key={index} className="file-item">
              <span>{file.name}</span>
              <button type="button" onClick={() => handleDelete(index)}>Delete</button>
            </div>
          ))}
        </div> */}

        <button style={{backgroundColor:'#0070A9'}} type="submit">Submit</button>
      </form>
    </div>
    </div>
    </>
    
  )
}

export default Clienthome
