import React from 'react'
import { Doughnut, Bar } from 'react-chartjs-2';
import {Chart, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title} from 'chart.js'
Chart.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title);
// import '../styles/Dough.css'

const Doughchart = ({xdata,label}) => {
    const data = {
      labels: label && label,
      datasets: [
        {
          label: '# of Votes',
          data: xdata && xdata,
          backgroundColor: [
            '#EDDC95',
            '#A9C5DA',
            '#A1E3CB',
            '#B1E3FF',
          ],

          hoverOffset: 4
        },
      ],
    };

    const options = {
        responsive:true,
        plugins: {
            legend: {
                display: false,
                position:"right",

                labels: {
                    boxwidth:20,
                    padding:20
                }
            }
        },
        layout:{
            padding:{
                right:20,
                top:0,
                bottom:0,
                left:0
            }
        },
        maintainAspectRatio:false,
        tooltip:{
            enabled:true
        }
        
      };

    
  
    // return <Doughnut  data={data} options={options} />;
    return <Bar data={data} options={options} />;
  };

export default Doughchart
