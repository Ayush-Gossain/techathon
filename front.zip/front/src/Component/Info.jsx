import React,{useEffect,useState, useRef} from 'react'
import '../Styles/Info.css'
import { useParams } from 'react-router-dom'
import Typewriter from 'typewriter-effect'

import CheckIcon from '@mui/icons-material/Check';

import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import Tooltip from '@mui/material/Tooltip';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';

const Info = () => {
    const  {claim_id} = useParams()
    const [thisdata,setThisdata] = useState()
    const [message,setmessage] = useState([{text:"",type:""}])
    const [question,setquestion] = useState('')


    const [open, setOpen] = React.useState(false);
      const [msg,setMsg] = useState('')
      const [alert,setAlert] = useState('')
      const [openBackdrop, setOpenBackdrop] = React.useState(false);
    // const chatContainerRef = useRef(null);


    // useEffect(()=>{
    //     // console.log(message);
    //     if (chatContainerRef.current) {
    //       chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    //     }
    //     const scrollelement = document.getElementById('scroll')
    //     // if(scrollelement && message.length>0){
    //     //   scrollelement.scrollIntoView({behavior:'smooth'});
    //     // }
        
    // },[message])

    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
          return;
        }
      }




    const getdata = async() =>{
        setOpenBackdrop(true)
        console.log('type called');
        try {
          await fetch(`http://127.0.0.1:5000/get_claim_details/${claim_id}`,{
            method:"get",
            // headers:{
            //   'Authorization': `Bearer ${token}`
            // }
            }).then(res=>res.json())
            .then(data=>{
              
                console.log(data)
                setThisdata(data)
                setAlert('success')
                setMsg('success')
                setOpenBackdrop(false)
                // setmaindata(data)
               
            }).catch(err=>{
              console.log(err)
              setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
            })
          
        } catch (error) {
          alert('error',error)
          setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
          
        }
    }

    const handleask = async()=>{
        setOpenBackdrop(true)
        setmessage((prevMessage)=>[...prevMessage,{text:question,type:'user'}])
        const formdata = new FormData
        formdata.append('question',question)
        formdata.append('claim_id',claim_id)
        
        try {
            await fetch(`http://127.0.0.1:5000/qna`,{
              method:"post",
              
                body:formdata
              
              }).then(res=>res.json())
              .then(data=>{
                setmessage((prev)=>[...prev,{text:data.text,type:"bot"}])
                setAlert('success')
                setMsg('success')
                setOpenBackdrop(false)
              }).catch(err=>{
                console.log(err)
                setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
              })
            
          } catch (error) {
            alert('error',error)
            setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
            
          }
    }

    const thisstream = async()=>{
        const response = await fetch(`http://127.0.0.1:5000/stream-text`);
        if(!response.body) return;
        const reader = response.body.getReader();
        const decoder = new TextDecoder();

        while(true){
            const {done, value} = await reader.read();
            if (done) break;

            const text = decoder.decode(value).trim();
            if(text){
                // [...prev,{text:text,type:'bot'}]
                setmessage(prev=>{
                    const update = [...prev];
                    const last = update.length - 1
                    if(!update[last].text.endsWith(text)){
                        update[last].text += text
                    }
                    
                    update[update.length - 1].type = 'bot'
                    return update
                })
            }
            console.log(text)

        }
        
    }





    useEffect(()=>{
            getdata()
          },[])



  return (<>

<Backdrop
        sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={openBackdrop}
        // onClick={handleClose}
      >
        <CircularProgress color="inherit" />
      </Backdrop>


      <Snackbar anchorOrigin={{ vertical: 'top', horizontal: 'right' }} open={open} autoHideDuration={5000} onClose={handleClose}>
        <Alert
          onClose={handleClose}
          severity={alert}
          variant="filled"
          sx={{ width: '100%' }}
        >
          {msg}
        </Alert>
      </Snackbar>
  
  
  
  
    <div className='best'>
        <div className="left">
            <div className="mainchatbox">
                    <div className='ggsection'>
                        <div className="first">
                        <h3 style={{marginBottom:'0px'}}>Personal Details</h3>
                        <div className="ggflex">
                        <p style={{fontWeight:'500',marginBottom:'0px',display:'flex',flexDirection:'row',alignItems:'center'}} >UserId : <p style={{textDecoration:'none',marginTop:'16px'}}>{thisdata && thisdata[0].user_details[0].policy_id}</p></p>
                        <p style={{fontWeight:'500',marginBottom:'0px',display:'flex',flexDirection:'row',alignItems:'center'}} >Name : <p style={{textDecoration:'none',marginTop:'16px'}}>{thisdata && thisdata[0].user_details[0].name}</p></p>
                        <p style={{fontWeight:'500',marginBottom:'0px',display:'flex',flexDirection:'row',alignItems:'center'}} >Age : <p style={{textDecoration:'none',marginTop:'16px'}}>{thisdata && thisdata[0].user_details[0].age}</p></p>
                        </div>
                        <p style={{fontWeight:'500',marginBottom:'0px',display:'flex',flexDirection:'row',alignItems:'center'}} >PrevClaimsNo : <p style={{textDecoration:'none',marginTop:'16px'}}>0</p></p>
                        <div className="ggflex">
                        
                        <p style={{fontWeight:'500',marginBottom:'0px',display:'flex',flexDirection:'row',alignItems:'center'}} >StartDate : <p style={{textDecoration:'none',marginTop:'16px'}}>{thisdata && thisdata[0].user_details[0].policy.start_date}</p></p>
                        <p style={{fontWeight:'500',marginBottom:'0px',display:'flex',flexDirection:'row',alignItems:'center'}} >EndDate : <p style={{textDecoration:'none',marginTop:'16px'}}>{thisdata && thisdata[0].user_details[0].policy.end_date}</p></p>
                        
                        </div>
                        
                        
                    </div>
                    
                    
                    
                </div>
                <div className='ggsection'>
                        <div className="first">
                        <h3 style={{marginBottom:'0px'}}>Claim Details</h3>
                        <div className="ggflex">
                        <p style={{fontWeight:'500',marginBottom:'0px',display:'flex',flexDirection:'row',alignItems:'center'}} >ClaimId : <p style={{textDecoration:'none',marginTop:'16px'}}>{thisdata && thisdata[0].claim_id}</p></p>
                        <p style={{fontWeight:'500',marginBottom:'0px',display:'flex',flexDirection:'row',alignItems:'center'}} >Hospital : <p style={{textDecoration:'none',marginTop:'16px'}}>{thisdata && thisdata[0].hospital_details[0].hospital_name}</p></p>
                        
                        </div>
                        <p style={{fontWeight:'500',marginBottom:'0px',display:'flex',flexDirection:'row',alignItems:'center'}} >Disease : <p style={{textDecoration:'none',marginTop:'16px'}}>{thisdata && thisdata[0].diagnosis_details[0].disease_name}</p></p>
                        
                        <p style={{fontWeight:'500',marginBottom:'0px',display:'flex',flexDirection:'row',alignItems:'center'}} >Desc : <p style={{textDecoration:'none',marginTop:'16px'}}>Ayush Gossain</p></p>



                        


                        {/* <div className="thisfile">
                        <div className="uploadedfile">
                        <p style={{fontWeight:'500',marginBottom:'0px',display:'flex',flexDirection:'row',alignItems:'center'}} >File_name.pdf</p>
                        <div className="icon"></div>
                        </div>
                        <div className="uploadedfile">
                        <p style={{fontWeight:'500',marginBottom:'0px',display:'flex',flexDirection:'row',alignItems:'center'}} >File_name.pdf</p>
                        <div className="icon"></div>
                        </div>
                        <div className="uploadedfile">
                        <p style={{fontWeight:'500',marginBottom:'0px',display:'flex',flexDirection:'row',alignItems:'center'}} >File_name.pdf</p>
                        <div className="icon"></div>
                        </div>
                        </div> */}

                        
                        
                        



                    </div>
                </div>    
                <div className="appbutton">
                    <div className="approve"><svg style={{position:'relative',top:'6px',left:'5px'}} width="30" height="30" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path fill-rule="evenodd" clip-rule="evenodd" d="M14.354 4.354L7.354 11.354C7.30755 11.4006 7.25238 11.4375 7.19163 11.4627C7.13088 11.4879 7.06576 11.5009 7 11.5009C6.93423 11.5009 6.86911 11.4879 6.80836 11.4627C6.74762 11.4375 6.69244 11.4006 6.646 11.354L2.646 7.354L3.354 6.646L7 10.293L13.647 3.646L14.354 4.354Z" fill="white"/>
</svg></div>
                    <div className="reject">
                    <svg style={{position:'relative',top:'6px',left:'5px'}} width="30" height="30" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M11.25 4.75L4.75 11.25M4.75 4.75L11.25 11.25" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
                    </div>
                    
                </div>
            </div>
            
        </div>
        <div className="right">
        <div className="mainchatbox">
        <div className="chattop">
            <div className="breadcrumb">
                <p className="prev">Admin</p>
                <p className="prev">/</p>
                <p className="boldprev">Chat</p>
            </div>
            {/* <button className="clearchat">Clear Chat</button> */}
        </div>
        <div className="mainchat" >
        
            {
                message && message.map((item,index)=>{
                    return (<>
                    {
                          item.text?(
                            <div className={item.type=='bot'?'chatboxleft':"chatboxright"}>
                <div className="topicon">
                    {/* <div className="toptime">8:10am</div> */}
                </div>
                <div className="chattext">
                    {item.text}
                        
                    
                    
                    </div>
                
            </div>
                         ):("") 
                     } 
                    
                    
                    {/* {
                          item.text?(
                            <div className={item.type=='bot'?'chatboxleft':"chatboxright"}>
                <div className="topicon">
                    <div className="toptime">8:10am</div>
                </div>
                <div className="chattext">
                    
                            <Typewriter options={{
                                strings:item.text,
                                autoStart:true,
                                delay:50,
                                cursor:""
                            }}/>
                        
                    
                    
                    </div>
                
            </div>
                         ):("") 
                     }  */}
                    

                    </>)
                })
            }
            
        </div>
        <div className="toptext">
            <div className='generate' onClick={thisstream}>Generate Summary</div>
            {/* <div className='recommend'>
                <div className="rec">Tax Implications</div>
                <div className="rec">Fees and Expenses</div>
                <div className="rec">Asset Allocation</div>
                <div className="more"></div>
            </div> */}
        </div>
        <div className="textarea">
            <input onChange={(e)=>setquestion(e.target.value)} className='text' placeholder='Ask Me Anything.....' type="text" />
            <button className='send' onClick={handleask}>
            <svg style={{position:'relative',top:'-2px',left:'-4px'}} width="25" height="25" viewBox="0 0 25 25" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M22.667 2.61963L11.667 13.6196" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        <path d="M22.667 2.61963L15.667 22.6196L11.667 13.6196L2.66699 9.61963L22.667 2.61963Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
            </button>
        </div>
    </div>
        </div>
      
    </div>
    </>
  )
}

export default Info
