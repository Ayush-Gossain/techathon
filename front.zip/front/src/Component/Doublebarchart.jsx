import React from 'react'
import { Doughnut, Bar } from 'react-chartjs-2';
import {Chart, ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title} from 'chart.js'
import { data } from 'react-router-dom';
Chart.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement, Title);

const Doublebarchart = ({data1,data2,label}) => {
     const data = {
          labels: label && label,
          datasets: [
            {
              label: 'fraud',
              data: data1 && data1,
              backgroundColor: 'red',
    
              hoverOffset: 4
            },
            {
                label: 'Non-Fraud',
                data: data2 && data2,
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
              },
          ],
        };
    
        const options = {
            responsive:true,
            plugins: {
                legend: {
                    display: false,
                    position:"right",
    
                    labels: {
                        boxwidth:20,
                        padding:20
                    }
                }
            },
            layout:{
                padding:{
                    right:20,
                    top:0,
                    bottom:0,
                    left:0
                }
            },
            maintainAspectRatio:false,
            tooltip:{
                enabled:true
            },
            scales: {
                x: {
                  stacked: true,
                },
                y: {
                  stacked: true,
                }}
            
          };
    
        
      
        // return <Doughnut  data={data} options={options} />;
        return <Bar data={data} options={options} />;
  
}

export default Doublebarchart
