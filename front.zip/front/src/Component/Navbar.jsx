import React from 'react'
import { Link } from "react-router-dom";
import '../Styles/Navbar.css'
import image from '../assets/logo/LTIMindtree.png'

const Navbar = ({isloggedin,usertype}) => {
  return (
    <div className='wholenav'>
      <div className='logoname'>
        <div className="logo"><img src={image} alt="logo" style={{height:'34px'}} /></div>
        <div className="toparrow"></div>
        <p className='p'>IQ Agent</p>
      </div>
      <div className="navright">
        <ul>
          {!isloggedin && (<>
            <li><Link to="/login" style={{textDecoration:'none'}}>Login</Link></li>
            <li><Link to="/reg" style={{textDecoration:'none'}}>Register</Link></li>
          </>)}
          {
            isloggedin && usertype == 'approver'?(<>
            <li><Link to="/admin" style={{textDecoration:'none'}}>Home</Link></li>
            <li><Link to="/report" style={{textDecoration:'none'}}>Report</Link></li>
            <li><Link to="/about" style={{textDecoration:'none'}}>About</Link></li>
            </>): isloggedin && usertype == 'user'?(<>
              {/* <li><Link to="/client" style={{textDecoration:'none'}}>Client</Link></li> */}
              <li style={{marginLeft:'200px'}}><Link to="/about" style={{textDecoration:'none'}}>About</Link></li>
              </>):isloggedin &&(<>
                <li><Link to="/workflow" style={{textDecoration:'none'}}>Workflow</Link></li>
                <li><Link to="/about" style={{textDecoration:'none'}}>About</Link></li>
              </>)
          }
            
            
            
        </ul>
        <div className="profile"></div>
      </div>
    </div>
  )
}

export default Navbar
