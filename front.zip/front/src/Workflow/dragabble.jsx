import React, { useState, useEffect, useCallback } from 'react';
import {
  ReactFlow,
  ReactFlowProvider,
  addEdge,
  useNodesState,
  useEdgesState,
  Background,
} from 'reactflow';
import 'reactflow/dist/style.css';
import './WorkflowEditor.css';

const API_BASE = "http://127.0.0.1:5000";

const WorkflowEditor = () => {
  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [sidebarData, setSidebarData] = useState({
    workflows: [],
    agents: [],
    genAIModels: [],
    generalModels: [],
    knowledgeGraphs: [],
  });

  // Fetch sidebar data from API
  useEffect(() => {
    const fetchData = async () => {
      try {
        const workflows = await fetch(`${API_BASE}/api/sidebarWorkflows`).then((res) => res.json());
        const agents = await fetch(`${API_BASE}/api/sidebarAgents`).then((res) => res.json());
        const genAIModels = await fetch(`${API_BASE}/api/sidebarGenaimodels`).then((res) => res.json());
        const generalModels = await fetch(`${API_BASE}/api/sidebarGeneralmodels`).then((res) => res.json());
        const knowledgeGraphs = await fetch(`${API_BASE}/api/KnowledgeGraph`).then((res) => res.json());

        setSidebarData({ workflows, agents, genAIModels, generalModels, knowledgeGraphs });
      } catch (error) {
        console.error('Error fetching sidebar data:', error);
      }
    };
    fetchData();
  }, []);

  // Drag-and-drop handlers for sidebar nodes
  const onDragStart = (event, nodeData) => {
    event.dataTransfer.setData('application/reactflow', JSON.stringify(nodeData));
    event.dataTransfer.effectAllowed = 'move';
  };

  const onDrop = (event) => {
    event.preventDefault();
    const reactFlowBounds = event.target.getBoundingClientRect();
    const data = JSON.parse(event.dataTransfer.getData('application/reactflow'));

    const position = {
      x: event.clientX - reactFlowBounds.left,
      y: event.clientY - reactFlowBounds.top,
    };

    const newNode = {
      id: `${data.id}-${Date.now()}`,
      position,
      data: { label: data.name },
      type: 'default', // Use React Flow's default node type
    };

    setNodes((prevNodes) => [...prevNodes, newNode]);
  };

  const onDragOver = (event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  };

  // Sidebar rendering
  const renderSidebarSection = (title, items, type) => (
    <div className="sidebar-section">
      <h3>{title}</h3>
      <div className="sidebar-nodes">
        {items.map((item) => (
          <div
            key={item.id}
            className={`sidebar-node ${type}-node ${item.disabled ? 'disabled' : ''}`}
            draggable={!item.disabled}
            onDragStart={(event) => !item.disabled && onDragStart(event, item)}
          >
            {item.name}
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="editor-container">
      {/* Sidebar */}
      <div className="sidebar">
        <h2>Collections</h2>
        {renderSidebarSection('Workflows', sidebarData.workflows, 'workflow')}
        {renderSidebarSection('Agents', sidebarData.agents, 'agent')}
        {renderSidebarSection('GenAI Models', sidebarData.genAIModels, 'genai')}
        {renderSidebarSection('General Models', sidebarData.generalModels, 'general')}
        {renderSidebarSection('Knowledge Graphs', sidebarData.knowledgeGraphs, 'kg')}
      </div>

      {/* Canvas */}
      <div className="workflow-canvas" onDrop={onDrop} onDragOver={onDragOver}>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          fitView
        >
          <Background />
        </ReactFlow>
      </div>
    </div>
  );
};

const WorkflowEditorWrapper = () => (
  <ReactFlowProvider>
    <WorkflowEditor />
  </ReactFlowProvider>
);

export default WorkflowEditorWrapper;
