export const initialEdges = [
  {
    "id": "AG_12345678_AG_87654321",
    "source": "AG_12345678",
    "target": "AG_87654321",
    "source_node_id": "1",
    "target_node_id": "2"
  },
  {
    "id": "AG_87654321_GM_87654321",
    "source": "AG_87654321",
    "target": "GM_87654321",
    "source_node_id": "2",
    "target_node_id": "3"
  },
  {
    "id": "AG_87654321_GM_11223344",
    "source": "AG_87654321",
    "target": "GM_11223344",
    "source_node_id": "2",
    "target_node_id": "4"
  },
  {
    "id": "KG_12345678_GM_11223344",
    "source": "KG_12345678",
    "target": "GM_11223344",
    "source_node_id": "2",
    "target_node_id": "4"
  },
  {
    "id": "AG_87654321_GM_12345678",
    "source": "AG_87654321",
    "target": "GM_12345678",
    "source_node_id": "2",
    "target_node_id": "5"
  },
  {
    "id": "AG_87654321_GM_44556677",
    "source": "AG_87654321",
    "target": "GM_44556677",
    "source_node_id": "2",
    "target_node_id": "6"
  },
  {
    "id": "GM_87654321_AG_11223344",
    "source": "GM_87654321",
    "target": "AG_11223344",
    "source_node_id": "3",
    "target_node_id": "3"
  },
  {
    "id": "GM_11223344_AG_11223344",
    "source": "GM_11223344",
    "target": "AG_11223344",
    "source_node_id": "4",
    "target_node_id": "3"
  },
  {
    "id": "GM_12345678_AG_11223344",
    "source": "GM_12345678",
    "target": "AG_11223344",
    "source_node_id": "5",
    "target_node_id": "3"
  },
  {
    "id": "GM_44556677_AG_11223344",
    "source": "GM_44556677",
    "target": "AG_11223344",
    "source_node_id": "6",
    "target_node_id": "3"
  }
];