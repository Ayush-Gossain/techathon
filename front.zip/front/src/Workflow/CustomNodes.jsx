// CustomNodes.jsx
import React from 'react';
import './CustomNodes.css';

export const AgentNode = ({ data }) => {
  return <div className="agent-node">{data.label}</div>;
};

export const ModelNode = ({ data }) => {
  return <div className="model-node">{data.label}</div>;
};

export const KnowledgeGraphNode = ({ data }) => {
  return (
    <div className="kg-node">
      <div>{data.label}</div>
    </div>
  );
};
