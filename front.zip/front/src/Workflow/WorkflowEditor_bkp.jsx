// WorkflowEditor.jsx
import React, { useState, useCallback } from 'react';
import {
  ReactFlow,
  addEdge,
  applyNodeChanges,
  applyEdgeChanges,
  ReactFlowProvider,
  Handle,
  Position,
} from '@xyflow/react';
import 'reactflow/dist/style.css';
import './WorkflowEditor.css';

// Custom node for the workflow canvas. It uses the flags in data (showInput/showOutput)
// and the domain type (data.nodeType) to render different shapes and handles.
const CustomWorkflowNode = ({ data }) => {
  return (
    <div className={`custom-workflow-node ${data.nodeType}`}>
      {data.showInput && (
        <Handle
          type="target"
          position={Position.Left}
          style={{ background: '#555', width: '10px', height: '10px' }}
        />
      )}
      <div className="custom-workflow-node-label">{data.label}</div>
      {data.showOutput && (
        <Handle
          type="source"
          position={Position.Right}
          style={{ background: '#555', width: '10px', height: '10px' }}
        />
      )}
    </div>
  );
};


// For Workflows, we use an "executable" flag that determines whether the node is draggable.
const Workflows = [
  { id: 'WR_98989432', name: 'Fraud Detection Workflow', executable: true },
  { id: 'WR_98765432', name: 'QML Workflow', executable: false },
];

// For Agents, we use a "disabled" flag.
const Agents = [
  { id: 'AG_12345678', name: 'File Uploader Agent', disabled: false },
  { id: 'AG_87654321', name: 'Fraud Feature Collector', disabled: false },
  { id: 'AG_11223344', name: 'Fraud Identification & Detector', disabled: false }
];

const GenAIModels = [
    { id: 'M_12345678', name: 'OpenAI', active: true },
    { id: 'M_87654321', name: 'Lama', active: false },
    { id: 'M_56789012', name: 'DeepSeek R1', active: false }
  ];

const GeneralModels = [
    { id: 'GM_87654321', name: 'QML Fraud Detection', active: true  },
    { id: 'GM_11223344', name: 'Azure OpenAI Disease Validation', active: true  },
    { id: 'GM_12345678', name: 'Random Forest Fraud Detection', active: true  },
    { id: 'GM_44556677', name: 'CNN Face Mapper', active: true  },
  ];

  const KnowledgeGraphs = [
    { id: 'KG_12345678', name: 'City Health Knowledge Graph', active: true  },
  ];

// --- Sample workflow diagram data ---
// Note: We now use type: 'custom' so that our CustomWorkflowNode renders.
// We include flags (showInput/showOutput) to control which handles appear,
// and data.nodeType to determine the shape/color.
const initialWorkflowNodes = [
  {
    id: 'AG_12345678',
    type: 'custom',
    position: { x: -120, y: -80 },
    data: { label: 'File Uploader Agent', nodeType: 'agent', showInput: false, showOutput: true },
  },
  {
    id: 'AG_87654321',
    type: 'custom',
    position: { x: 120, y: 0 },
    data: { label: 'Fraud Feature Collector', nodeType: 'agent', showInput: true, showOutput: true },
  },
  {
    id: 'GM_87654321',
    type: 'custom',
    position: { x: 120, y: 95 },
    data: { label: 'Quantum Fraud Detector', nodeType: 'model', showInput: true, showOutput: true },
  },
  {
    id: 'GM_11223344',
    type: 'custom',
    position: { x: 70, y: 60 },
    data: { label: 'Azure OpenAI Disease Validation', nodeType: 'model', showInput: true, showOutput: true },
  },
  {
    id: 'KG_12345678',
    type: 'custom',
    position: { x: -50, y: 0 },
    data: { label: 'City Health Knowledge Graph', nodeType: 'knowledgeGraph', showInput: false, showOutput: true },
  },
  {
    id: 'GM_44556677',
    type: 'custom',
    position: { x: -220, y: 105 },
    data: { label: 'CNN Face Mapper', nodeType: 'model', showInput: true, showOutput: true },
  },
  {
    id: 'GM_12345678',
    type: 'custom',
    position: { x: 290, y: 95 },
    data: { label: 'Classical Fraud Detector', nodeType: 'model', showInput: true, showOutput: true },
  },
  {
    id: 'AG_11223344',
    type: 'custom',
    position: { x: 120, y: 190 },
    data: { label: 'Fraud Identification & Detector', nodeType: 'agent', showInput: true, showOutput: false },
  },
];

const initialWorkflowEdges = [
  { id: 'e1', source: 'AG_12345678', target: 'AG_87654321' },
  { id: 'e2', source: 'AG_87654321', target: 'GM_87654321' },
  { id: 'e3', source: 'AG_87654321', target: 'GM_11223344' },
  { id: 'e4', source: 'AG_87654321', target: 'GM_44556677' },
  { id: 'e5', source: 'AG_87654321', target: 'GM_12345678' },
  { id: 'e6', source: 'KG_12345678', target: 'GM_11223344' },
  { id: 'e9', source: 'GM_87654321', target: 'AG_11223344' },
  { id: 'e10', source: 'GM_11223344', target: 'AG_11223344' },
  { id: 'e11', source: 'GM_44556677', target: 'AG_11223344' },
  { id: 'e12', source: 'GM_12345678', target: 'AG_11223344' }
];

// Map our custom type name to our component.
const nodeTypes = {
  custom: CustomWorkflowNode,
};

const WorkflowEditor = () => {
  // Left sidebar state (this could be fetched from your API)
  const [workflows] = useState(Workflows);
  const [agents] = useState(Agents);
  const [genAIModels] = useState(GenAIModels);
  const [generalModels] = useState(GeneralModels);
  const [knowledgeGraphs] = useState(KnowledgeGraphs);

  // Workflow canvas state
  const [nodes, setNodes] = useState(initialWorkflowNodes);
  const [edges, setEdges] = useState(initialWorkflowEdges);

  // Display the name of the first workflow as the current workflow.
  const currentWorkflowName = workflows.length > 0 ? workflows[0].name : 'No Workflow Selected';

  // Sidebar item click handlers.
  const selectWorkflow = (workflow) => {
    console.log('Workflow selected:', workflow);
    // Fetch and load the selected workflow into the canvas as needed.
  };

  const selectAgent = (agent) => {
    console.log('Agent selected:', agent);
    // Handle agent selection if needed.
  };

  const selectGenAIModels = (genAIModel) => {
    console.log('GenAI Models selected:', genAIModel);
    // Handle agent selection if needed.
  };

  const selectGeneralModels = (generalModel) => {
    console.log('General Models selected:', generalModel);
    // Handle agent selection if needed.
  };

  const selectKnowledgeGraphs = (knowledgeGraph) => {
    console.log('Knowledge Graphs selected:', knowledgeGraph);
    // Handle agent selection if needed.
  };

  // Button click to update the workflow (call your API here)
  const updateWorkflow = () => {
    console.log('Updating workflow with current diagram:', { nodes, edges });
    // e.g., fetch('/api/update_workflow', { method: 'POST', body: JSON.stringify({ nodes, edges }) })
  };

  // Callbacks to update React Flow’s nodes/edges.
  const onNodesChange = useCallback(
    (changes) => setNodes((nds) => applyNodeChanges(changes, nds)),
    []
  );
  const onEdgesChange = useCallback(
    (changes) => setEdges((eds) => applyEdgeChanges(changes, eds)),
    []
  );
  const onConnect = useCallback(
    (connection) => setEdges((eds) => addEdge(connection, eds)),
    []
  );

  return (
    <div className="editor-container">
      {/* LEFT SIDEBAR */}
      <div className="sidebar">
        <h2>Collections</h2>

        {/* Workflows Section */}
        <div className="sidebar-section">
          <h3>Workflows</h3>
          <div className="sidebar-nodes">
            {workflows.map((wf) => (
              <div
                key={wf.id}
                className={`sidebar-node workflow-node ${!wf.executable ? 'disabled' : ''}`}
                draggable={wf.executable}
                onClick={() => selectWorkflow(wf)}
              >
                {wf.name}
              </div>
            ))}
          </div>
        </div>

        {/* Agents Section */}
        <div className="sidebar-section">
          <h3>Agents</h3>
          <div className="sidebar-nodes">
            {agents.map((agent) => (
              <div
                key={agent.id}
                className={`sidebar-node agent-node ${agent.disabled ? 'disabled' : ''}`}
                draggable={!agent.disabled}
                onClick={() => selectAgent(agent)}
              >
                {agent.name}
              </div>
            ))}
          </div>
        </div>

        {/* General Model Section */}
        <div className="sidebar-section">
          <h3>General Models</h3>
          <div className="sidebar-nodes">
            {generalModels.map((generalModel) => (
              <div
                key={generalModel.id}
                className={`sidebar-node agent-node ${generalModel.disabled ? 'disabled' : ''}`}
                draggable={!generalModel.disabled}
                onClick={() => selectAgent(generalModel)}
              >
                {generalModel.name}
              </div>
            ))}
          </div>
        </div>

        {/* GenAI Model Section */}
        <div className="sidebar-section">
          <h3>GenAI Models</h3>
          <div className="sidebar-nodes">
            {genAIModels.map((genAIModel) => (
              <div
                key={genAIModel.id}
                className={`sidebar-node agent-node ${genAIModel.disabled ? 'disabled' : ''}`}
                draggable={!genAIModel.active}
                onClick={() => selectAgent(genAIModel)}
              >
                {genAIModel.name}
              </div>
            ))}
          </div>
        </div>

        {/* Knowledge Graph Section */}
        <div className="sidebar-section">
          <h3>Knowledge Graphs</h3>
          <div className="sidebar-nodes">
            {knowledgeGraphs.map((knowledgeGraph) => (
              <div
                key={knowledgeGraph.id}
                className={`sidebar-node agent-node ${knowledgeGraph.disabled ? 'disabled' : ''}`}
                draggable={!knowledgeGraph.active}
                onClick={() => selectAgent(knowledgeGraph)}
              >
                {knowledgeGraph.name}
              </div>
            ))}
          </div>
        </div>
      </div>


      {/* RIGHT WORKFLOW CANVAS */}
      <div className="workflow-canvas">
        <h2>Workflow: {currentWorkflowName}</h2>
        <ReactFlow
          nodes={nodes}
          edges={edges}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          nodeTypes={nodeTypes}
          fitView
        />
        <button className="update-btn" onClick={updateWorkflow}>
          Update Workflow
        </button>
      </div>
    </div>
  );
};

const WorkflowEditorWrapper = () => (
  <ReactFlowProvider>
    <WorkflowEditor />
  </ReactFlowProvider>
);

export default WorkflowEditorWrapper;