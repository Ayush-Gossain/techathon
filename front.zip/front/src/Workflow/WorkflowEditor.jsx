import React, { useState, useEffect, useCallback } from 'react';
import {
 ReactFlow,
 addEdge,
 applyNodeChanges,
 applyEdgeChanges,
 ReactFlowProvider,
 Handle,
 Position,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import './WorkflowEditor.css';
// Base URL for your Flask API (adjust if needed)
const API_BASE = "http://127.0.0.1:5000";
// Custom node for the workflow canvas.
// Renders input/output handles based on data flags and applies different styling based on data.nodeType.
const CustomWorkflowNode = ({ data }) => {
 return (
<div className={`custom-workflow-node ${data.nodeType}`}>
     {data.showInput && (
<Handle
         type="target"
         position={Position.Left}
         style={{ background: '#555', width: '10px', height: '10px' }}
       />
     )}
<div className="custom-workflow-node-label">{data.label}</div>
     {data.showOutput && (
<Handle
         type="source"
         position={Position.Right}
         style={{ background: '#555', width: '10px', height: '10px' }}
       />
     )}
</div>
 );
};
// Map our custom node type to our component.
const nodeTypes = {
 custom: CustomWorkflowNode,
};
const WorkflowEditor = () => {
 // Sidebar collection states (fetched from the API)
 const [workflows, setWorkflows] = useState([]);
 const [agents, setAgents] = useState([]);
 const [genAIModels, setGenAIModels] = useState([]);
 const [generalModels, setGeneralModels] = useState([]);
 const [knowledgeGraphs, setKnowledgeGraphs] = useState([]);
 // Canvas state (nodes and edges come from the selected workflow)
 const [nodes, setNodes] = useState([]);
 const [edges, setEdges] = useState([]);
 // State for the currently used/selected workflow (from the SelectedWorkflow collection)
 const [currentSelectedWorkflow, setCurrentSelectedWorkflow] = useState(null);
 // Pagination state (for workflows)
 const [currentPage, setCurrentPage] = useState(1);
 const workflowsPerPage = 1; // For example, one workflow per page
 // Toast state for update notifications
 const [toastMessage, setToastMessage] = useState('');
 // Fetch sidebar data on component mount
 useEffect(() => {
     fetch(`${API_BASE}/api/sidebarWorkflows`)
       .then((res) => res.json())
       .then((data) => setWorkflows(data))
       .catch((err) => console.error('Error fetching sidebar workflows:', err));
     fetch(`${API_BASE}/api/sidebarAgents`)
       .then((res) => res.json())
       .then((data) => setAgents(data))
       .catch((err) => console.error('Error fetching sidebar agents:', err));
     fetch(`${API_BASE}/api/sidebarGenaimodels`)
       .then((res) => res.json())
       .then((data) => setGenAIModels(data))
       .catch((err) => console.error('Error fetching sidebar GenAI models:', err));
     fetch(`${API_BASE}/api/sidebarGeneralmodels`)
       .then((res) => res.json())
       .then((data) => setGeneralModels(data))
       .catch((err) => console.error('Error fetching sidebar general models:', err));
     fetch(`${API_BASE}/api/KnowledgeGraph`)
       .then((res) => res.json())
       .then((data) => setKnowledgeGraphs(data))
       .catch((err) => console.error('Error fetching sidebar knowledge graphs:', err));
     fetch(`${API_BASE}/api/currentWorkflow`)
       .then((res) => res.json())
       .then((data) => setCurrentSelectedWorkflow(data))
       .catch((err) => console.error('Error fetching current workflow:', err));
   }, []);

 // Filter only executable workflows (for canvas display)
   const executableWorkflows = workflows.filter((wf) => wf.executable);
   const currentWorkflow =
     executableWorkflows.length > 0 ? executableWorkflows[currentPage - 1] : null;
   //   const currentWorkflow = currentSelectedWorkflow
   //   ? workflows.find((wf) => wf.id === currentSelectedWorkflow.workflow_id)
   //   : executableWorkflows.length > 0
   //   ? executableWorkflows[currentPage - 1]
   //   : null;

   // When the current workflow changes, fetch its canvas nodes and edges.
   useEffect(() => {
     if (currentWorkflow) {
       const workflowId = currentWorkflow.id;
       fetch(`${API_BASE}/api/canvasNodes?workflow_id=${workflowId}`)
         .then((res) => res.json())
         .then((data) => setNodes(data))
         .catch((err) => console.error('Error fetching canvas nodes:', err));
       fetch(`${API_BASE}/api/canvasEdges?workflow_id=${workflowId}`)
         .then((res) => res.json())
         .then((data) => setEdges(data))
         .catch((err) => console.error('Error fetching canvas edges:', err));
     } else {
       // Clear canvas if no workflow is selected.
       setNodes([]);
       setEdges([]);
     }
   }, [currentWorkflow]);
 // ReactFlow callbacks
 const onNodesChange = useCallback(
   (changes) => setNodes((nds) => applyNodeChanges(changes, nds)),
   []
 );
 const onEdgesChange = useCallback(
   (changes) => setEdges((eds) => applyEdgeChanges(changes, eds)),
   []
 );
 const onConnect = useCallback(
   (connection) => setEdges((eds) => addEdge(connection, eds)),
   []
 );
 // "Use this as Workflow" button handler:
 const updateWorkflow = () => {
   if (!currentWorkflow) return;
   // Call the endpoint to update the selected workflow.
   fetch(`${API_BASE}/api/useWorkflow`, {
     method: 'POST',
     headers: { 'Content-Type': 'application/json' },
     body: JSON.stringify({ workflowId: currentWorkflow.id }),
   })
     .then((res) => res.json())
     .then((data) => {
       // If the update returns a success message, update the current selected workflow and show a toast.
       if (data.message === 'Workflow saved successfully.') {
         setCurrentSelectedWorkflow({ workflow_id: currentWorkflow.id });
         setToastMessage('Workflow Updated');
         setTimeout(() => setToastMessage(''), 1000);
       }
     })
     .catch((err) => console.error('Error updating workflow:', err));
 };
 // Sidebar click handlers:
 const selectWorkflow = (wf) => {
   console.log('Selected workflow:', wf);
   // Optionally update pagination by finding the index of wf in executableWorkflows.
   const index = executableWorkflows.findIndex((w) => w.id === wf.id);
   if (index !== -1) {
     setCurrentPage(index + 1);
   }
 };

 const selectAgent = (agent) => {
   console.log('Selected agent:', agent);
 };
 const selectGenAIModel = (model) => {
   console.log('Selected GenAI model:', model);
 };
 const selectGeneralModel = (model) => {
   console.log('Selected general model:', model);
 };
 const selectKnowledgeGraph = (kg) => {
   console.log('Selected knowledge graph:', kg);
 };
 // Determine if the "Use this as Workflow" button should be disabled.
 const isWorkflowAlreadyUsed =
   currentSelectedWorkflow &&
   currentWorkflow &&
   currentSelectedWorkflow.workflow_id === currentWorkflow.id;
 // Drag-and-drop handlers for sidebar nodes
 const onDragStart = (event, nodeData) => {
   event.dataTransfer.setData('application/reactflow', JSON.stringify(nodeData));
   event.dataTransfer.effectAllowed = 'move';
 };
 const onDrop = (event) => {
   event.preventDefault();
   const reactFlowBounds = event.target.getBoundingClientRect();
   const data = JSON.parse(event.dataTransfer.getData('application/reactflow'));
   const position = {
     x: event.clientX - reactFlowBounds.left,
     y: event.clientY - reactFlowBounds.top,
   };
   const newNode = {
     id: `${data.id}-${Date.now()}`,
     position,
     data: { label: data.name },
     type: 'default', // Use React Flow's default node type
   };
   setNodes((prevNodes) => [...prevNodes, newNode]);
 };
 const onDragOver = (event) => {
   event.preventDefault();
   event.dataTransfer.dropEffect = 'move';
 };
 return (
<div className="editor-container">
     {/* LEFT SIDEBAR */}
<div className="sidebar">
<h2>Collections</h2>
       {/* Workflows Section */}
<div className="sidebar-section">
<h3>Workflows</h3>
<div className="sidebar-nodes">
           {workflows.map((wf) => (
<div
               key={wf.id}
               className={`sidebar-node workflow-node ${!wf.executable ? 'disabled' : ''}`}
               onClick={() => selectWorkflow(wf)}
>
               {wf.name}
</div>
           ))}
</div>
</div>
       {/* Agents Section */}
<div className="sidebar-section">
<h3>Agents</h3>
<div className="sidebar-nodes">
           {agents.map((agent) => (
<div
               key={agent.id}
               className={`sidebar-node agent-node ${agent.disabled ? 'disabled' : ''}`}
               onClick={() => selectAgent(agent)}
               draggable={!agent.disabled}
               onDragStart={(event) => !agent.disabled && onDragStart(event, agent)}
>
               {agent.name}
</div>
           ))}
</div>
</div>
       {/* GenAI Models Section */}
<div className="sidebar-section">
<h3>GenAI Models</h3>
<div className="sidebar-nodes">
           {genAIModels.map((model) => (
<div
               key={model.id}
               className={`sidebar-node genai-node ${!model.active ? 'disabled' : ''}`}
               onClick={() => selectGenAIModel(model)}
>
               {model.name}
</div>
           ))}
</div>
</div>
       {/* General Models Section */}
<div className="sidebar-section">
<h3>General Models</h3>
<div className="sidebar-nodes">
           {generalModels.map((model) => (
<div
               key={model.id}
               className={`sidebar-node general-node ${!model.active ? 'disabled' : ''}`}
               onClick={() => selectGeneralModel(model)}
               draggable={!model.disabled}
               onDragStart={(event) => !model.disabled && onDragStart(event, model)}
>
               {model.name}
</div>
           ))}
</div>
</div>
       {/* Knowledge Graphs Section */}
<div className="sidebar-section">
<h3>Knowledge Graphs</h3>
<div className="sidebar-nodes">
           {knowledgeGraphs.map((kg) => (
<div
               key={kg.id}
               className={`sidebar-node kg-node ${!kg.active ? 'disabled' : ''}`}
               onClick={() => selectKnowledgeGraph(kg)}
               draggable={!kg.disabled}
               onDragStart={(event) => !kg.disabled && onDragStart(event, model)}
>
               {kg.name}
</div>
           ))}
</div>
</div>
</div>
     {/* RIGHT WORKFLOW CANVAS */}
<div className="workflow-canvas" onDrop={onDrop} onDragOver={onDragOver}>
<h2>
         Workflow: {currentWorkflow ? currentWorkflow.name : 'No Workflow Selected'}
</h2>
<ReactFlow
         nodes={nodes}
         edges={edges}
         onNodesChange={onNodesChange}
         onEdgesChange={onEdgesChange}
         onConnect={onConnect}
         nodeTypes={nodeTypes}
         fitView
       />
<button
         className="update-btn"
         onClick={updateWorkflow}
         disabled={isWorkflowAlreadyUsed}
         title={isWorkflowAlreadyUsed ? "This workflow is already in use." : ""}
>
         Use this as Workflow
</button>
       {toastMessage && <div className="toast">{toastMessage}</div>}
</div>
</div>
 );
};
const WorkflowEditorWrapper = () => (
<ReactFlowProvider>
<WorkflowEditor />
</ReactFlowProvider>
);
export default WorkflowEditor;