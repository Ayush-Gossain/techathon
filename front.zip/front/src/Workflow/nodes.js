export const initialNodes = [
  {
      id: 'AG_12345678',
      type: 'input',
      position: { x: 120, y: -80 },
      data: { label: 'File Uploader Agent' }
    },
  {
    id: 'AG_87654321',
    position: { x: 120, y: 0 },
    data: { label: 'Fraud Feature Collector' }
  },
  {
    id: 'GM_87654321',
    position: { x: 120, y: 95 },
    data: { label: 'Quantum Fraud Detector' }
  },
  {
    id: 'GM_11223344',
    position: { x: -50, y: 90 },
    data: { label: 'OpenAI Disease Verification & Cost Checker' }
  },
  {
    id: 'KG_12345678',
    type: 'input',
    position: { x: -50, y: 0 },
    data: { label: 'City Health Knowledge Graph' }
  },
  {
    id: 'GM_44556677',
    position: { x: -220, y: 105},
    data: { label: 'CNN Face Mapper' }
  },
  {
    id: 'GM_12345678',
    position: { x: 290, y: 95 },
    data: { label: 'Classical Fraud Detector' }
  },
  {
    id: 'AG_11223344',
    type: 'output',
    position: { x: 120, y: 190 },
    data: { label: 'Fraud Identification & Detector' }
  }
];
