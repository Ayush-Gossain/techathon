import React from 'react'
import '../Styles/Chat.css'

const Chat = () => {
  return (
    <>
    <div className="mainchatbox">
        <div className="chattop">
            <div className="breadcrumb">
                <p className="prev">Admin</p>
                <p className="prev">/</p>
                <p className="boldprev">Chat</p>
            </div>
            {/* <button className="clearchat">Clear Chat</button> */}
        </div>
        <div className="mainchat">
            <div className="chatboxleft">
                <div className="topicon">
                    {/* <div className="boticon"></div> */}
                </div>
                <div className="chattext">this is text</div>
                {/* <div className="feedback">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="14.704" height="14.915" viewBox="0 0 14.704 14.915">
                        <path id="Icon_feather-thumbs-up" data-name="Icon feather-thumbs-up" d="M8.153,11.719V14.4a2.012,2.012,0,0,0,2.012,2.012l2.683-6.037V3H5.282A1.341,1.341,0,0,0,3.941,4.14l-.926,6.037a1.341,1.341,0,0,0,1.341,1.543ZM12.848,3H14.86A1.341,1.341,0,0,1,16.2,4.342v4.7a1.341,1.341,0,0,1-1.341,1.341H12.848" transform="translate(-2.247 -2.25)" fill="none" stroke="#7c7c7a" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
                        </svg>

                        <svg xmlns="http://www.w3.org/2000/svg" width="14.705" height="14.915" viewBox="0 0 14.705 14.915">
                        <path id="Icon_feather-thumbs-up" data-name="Icon feather-thumbs-up" d="M11.049,7.7V5.012A2.012,2.012,0,0,0,9.036,3L6.354,9.036v7.378h7.566a1.341,1.341,0,0,0,1.341-1.14l.926-6.036A1.341,1.341,0,0,0,14.845,7.7Zm-4.7,8.719H4.341A1.341,1.341,0,0,1,3,15.073v-4.7A1.341,1.341,0,0,1,4.341,9.036H6.354" transform="translate(-2.25 -2.25)" fill="none" stroke="#7c7c7a" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
                        </svg>

                                        <svg xmlns="http://www.w3.org/2000/svg" width="13.705" height="16.757" viewBox="0 0 13.705 16.757">
                        <g id="Icon_akar-copy" data-name="Icon akar-copy" transform="translate(0.75 0.75)">
                            <path id="Path_5252" data-name="Path 5252" d="M12,4.4v8.421a1.4,1.4,0,0,0,1.4,1.4h5.614a1.4,1.4,0,0,0,1.4-1.4V6.678a1.4,1.4,0,0,0-.422-1L17.672,3.4a1.4,1.4,0,0,0-.981-.4H13.4A1.4,1.4,0,0,0,12,4.4Z" transform="translate(-8.215 -3)" fill="none" stroke="#7c7c7a" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
                            <path id="Path_5253" data-name="Path 5253" d="M14.421,18.219v1.4a1.4,1.4,0,0,1-1.4,1.4H7.4a1.4,1.4,0,0,1-1.4-1.4V11.9a1.4,1.4,0,0,1,1.4-1.4h1.4" transform="translate(-6 -5.769)" fill="none" stroke="#7c7c7a" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
                        </g>
                        </svg>
                </div> */}
            </div>
            <div className="chatboxright">
                <div className="topicon">
                    <div className="toptime">8:10am</div>
                </div>
                <div className="chattext">this is text</div>
                {/* <div className="feedback">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="14.704" height="14.915" viewBox="0 0 14.704 14.915">
                        <path id="Icon_feather-thumbs-up" data-name="Icon feather-thumbs-up" d="M8.153,11.719V14.4a2.012,2.012,0,0,0,2.012,2.012l2.683-6.037V3H5.282A1.341,1.341,0,0,0,3.941,4.14l-.926,6.037a1.341,1.341,0,0,0,1.341,1.543ZM12.848,3H14.86A1.341,1.341,0,0,1,16.2,4.342v4.7a1.341,1.341,0,0,1-1.341,1.341H12.848" transform="translate(-2.247 -2.25)" fill="none" stroke="#7c7c7a" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
                        </svg>

                        <svg xmlns="http://www.w3.org/2000/svg" width="14.705" height="14.915" viewBox="0 0 14.705 14.915">
                        <path id="Icon_feather-thumbs-up" data-name="Icon feather-thumbs-up" d="M11.049,7.7V5.012A2.012,2.012,0,0,0,9.036,3L6.354,9.036v7.378h7.566a1.341,1.341,0,0,0,1.341-1.14l.926-6.036A1.341,1.341,0,0,0,14.845,7.7Zm-4.7,8.719H4.341A1.341,1.341,0,0,1,3,15.073v-4.7A1.341,1.341,0,0,1,4.341,9.036H6.354" transform="translate(-2.25 -2.25)" fill="none" stroke="#7c7c7a" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
                        </svg>

                                        <svg xmlns="http://www.w3.org/2000/svg" width="13.705" height="16.757" viewBox="0 0 13.705 16.757">
                        <g id="Icon_akar-copy" data-name="Icon akar-copy" transform="translate(0.75 0.75)">
                            <path id="Path_5252" data-name="Path 5252" d="M12,4.4v8.421a1.4,1.4,0,0,0,1.4,1.4h5.614a1.4,1.4,0,0,0,1.4-1.4V6.678a1.4,1.4,0,0,0-.422-1L17.672,3.4a1.4,1.4,0,0,0-.981-.4H13.4A1.4,1.4,0,0,0,12,4.4Z" transform="translate(-8.215 -3)" fill="none" stroke="#7c7c7a" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
                            <path id="Path_5253" data-name="Path 5253" d="M14.421,18.219v1.4a1.4,1.4,0,0,1-1.4,1.4H7.4a1.4,1.4,0,0,1-1.4-1.4V11.9a1.4,1.4,0,0,1,1.4-1.4h1.4" transform="translate(-6 -5.769)" fill="none" stroke="#7c7c7a" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5"/>
                        </g>
                        </svg>
                </div> */}
            </div>
        </div>
        <div className="toptext">
            <div className='generate'>Generate Summary</div>
            {/* <div className='recommend'>
                <div className="rec">Tax Implications</div>
                <div className="rec">Fees and Expenses</div>
                <div className="rec">Asset Allocation</div>
                <div className="more"></div>
            </div> */}
        </div>
        <div className="textarea">
            <input className='text' placeholder='Ask Me Anything.....' type="text" />
            <button className='send'></button>
        </div>
    </div>
    </>
  )
}

export default Chat
