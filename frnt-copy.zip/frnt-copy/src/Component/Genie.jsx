import React, { useState, useEffect } from 'react';
import '../Styles/Genie.css';

import image1 from '../assets/1.png';
import image2 from '../assets/2.png';
import image3 from '../assets/3.png';
import image4 from '../assets/4.png';
import image5 from '../assets/5.png';
// import logo from '../../assets/logo.svg';

const Genie = () => {
    const slides = [

        { id: 'slide4', src: image4, alt: 'Intelligent Data Processing with RAG' },
        { id: 'slide5', src: image5, alt: 'LLM for Natural Language Processing' },
        { id: 'slide1', src: image1, alt: 'Agentic AI' },
        { id: 'slide2', src: image2, alt: 'Classical Computing' },
        { id: 'slide3', src: image3, alt: 'Quantum Computing' }
        
        
    ];
    const [currentIndex, setCurrentIndex] = useState(0);

    useEffect(() => {
        const autoPlay = setInterval(() => {
            setCurrentIndex((prevIndex) => (prevIndex + 1) % slides.length);
        }, 3000);
        return () => clearInterval(autoPlay);
    }, [slides.length]);

    const getTransform = (index) => {
        const positions = [
            { transform: 'translateX(-100%) scale(0.8)', zIndex: 1 },
            { transform: 'translateX(-50%) scale(1.2)', zIndex: 2 },
            { transform: 'translateX(0%) scale(1.5)', zIndex: 3 },
            { transform: 'translateX(50%) scale(1.2)', zIndex: 2 },
            { transform: 'translateX(100%) scale(0.8)', zIndex: 1 },
        ];
        const adjustedIndex = (index - currentIndex + slides.length) % slides.length;
        return positions[adjustedIndex];
    };
  return (
    <div className="container">
            <div className="carousel-container">
                <div className="carousel">
                    {slides.map((slide, index) => (
                        <div className="slide" style={getTransform(index)} key={slide.id}>
                            <img src={slide.src} alt={slide.alt} />
                        </div>
                    ))}
                </div>
                <div className="carousel-controls">
                    {slides.map((_, index) => (
                        <input
                            key={index}
                            type="radio"
                            name="carousel"
                            checked={currentIndex === index}
                            onChange={() => setCurrentIndex(index)}
                        />
                    ))}
                </div>
            </div>
        </div>
  )
}

export default Genie
