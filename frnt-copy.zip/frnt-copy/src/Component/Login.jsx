import React,{useState} from 'react'
import '../Styles/Login.css'
import { useNavigate } from 'react-router-dom'
// imprt {useNavigate} from 'react-router-dom'

const Login = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        email: '',
        password: '',
      });
    
      const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
          ...prevState,
          [name]: value
        }));
      };
    
      const handleSubmit = async(e) => {
        e.preventDefault();
        try {
            await fetch(`http://127.0.0.1:5000/login`,{
              method:"post",
              headers:{
                  "Content-Type":"application/json"
              },
                body:JSON.stringify({
                  email:formData.email,
                  password:formData.password,
        
              })
              
              }).then(res=>res.json())
              .then(data=>{
                if(data.message && data.message === 'success'){
                    window.localStorage.setItem('type',data.type)
                    window.localStorage.setItem('isloggedin',true)
                    if (data.type == "approver") {
            
                        return (window.location.href = "./admin");
                      } else if(data.type == "user") {
                        // window.location.href = "./client";
                        navigate(`/client/${formData.email}`)
                      }else{
                        window.location.href="./workflow"
                      }
                    
                    // navigate('/')
                }
                
                  
                  
                 
              }).catch(err=>{
                console.log(err)
              })
            
          } catch (error) {
            alert('error',error)
            
          }
      };
  return (
    <form className="loginForm" >
      <h2 className="title">Welcome Back</h2>
      <p className="subtitle">Please login to your account</p>
      
      <div className="inputGroup">
        <input 
          type="email" 
          name="email"
          value={formData.email}
          onChange={handleChange}
          required 
        />
        <label>Email</label>
      </div>
      
      <div className="inputGroup">
        <input 
          type="password" 
          name="password"
          value={formData.password}
          onChange={handleChange}
          required 
        />
        <label>Password</label>
      </div>
      
      <div className="forgotPassword">
        <a href="#">Forgot Password?</a>
      </div>
      
      <button className="submitButton" type="button" onClick={handleSubmit}>Login</button>
      
      <div className="toggleForm">
        Don't have an account? 
        <span>Register</span>
      </div>
    </form>
  )
}

export default Login
