import React, {useState,useEffect} from 'react'
import '../Styles/Admin.css'
// import React from 'react'
// import Navbar from '../components/Navbar'
import Doughchart from '../Component/Doughchart'
import {useNavigate} from 'react-router-dom'


import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import Tooltip from '@mui/material/Tooltip';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';

const Adminhome = () => {
    const [dashdata, setdashdata] = useState();
    const navigate = useNavigate()
    const [recent,setrecent] = useState([])


    const [open, setOpen] = React.useState(false);
      const [msg,setMsg] = useState('')
      const [alert,setAlert] = useState('')
      const [openBackdrop, setOpenBackdrop] = React.useState(false);


    const first = () =>{
      if(window.localStorage.getItem('type')=='user'){
        navigate('/client')
      }else if(window.localStorage.getItem('type')=='developer'){
        navigate('/workflow')
        
      }else{
        getdashdata()
      }
    }
    const handleClose = (event, reason) => {
      if (reason === 'clickaway') {
        return;
      }
    }

    const getdashdata = async() =>{

      setOpenBackdrop(true)

      try {
        await fetch(`http://127.0.0.1:5000/dashboard`,{
          method:"get",
          // headers:{
          //   'Authorization': `Bearer ${token}`
          // }
          }).then(res=>res.json())
          .then(data=>{
            
              console.log(data)
              setdashdata(data)
              setAlert('success')
                setMsg('success')
                setOpenBackdrop(false)
                getrecentdata()
             
          }).catch(err=>{
            console.log(err)
            setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
          })
        
      } catch (error) {
        alert('error',error)
        setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
        
      }

    }
    const getrecentdata = async() =>{

      setOpenBackdrop(true)

      try {
        await fetch(`http://127.0.0.1:5000/get_recent_claims`,{
          method:"get",
          // headers:{
          //   'Authorization': `Bearer ${token}`
          // }
          }).then(res=>res.json())
          .then(data=>{
            
              console.log(data)
              setrecent(data)
              setAlert('success')
                setMsg('success')
                setOpenBackdrop(false)
             
          }).catch(err=>{
            console.log(err)
            setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
          })
        
      } catch (error) {
        alert('error',error)
        setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
        
      }

    }

  useEffect(() => {
    first()
  }, []);

  const handleMoreInfo = (id) => {
    // Handle the "More Info" button click
    console.log('More info for claim ID:', id);
  };
  return (
    <>

<Backdrop
        sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={openBackdrop}
        // onClick={handleClose}
      >
        <CircularProgress color="inherit" />
      </Backdrop>


      <Snackbar anchorOrigin={{ vertical: 'top', horizontal: 'right' }} open={open} autoHideDuration={5000} onClose={handleClose}>
        <Alert
          onClose={handleClose}
          severity={alert}
          variant="filled"
          sx={{ width: '100%' }}
        >
          {msg}
        </Alert>
      </Snackbar>





  <div className='topdash'>
      <div className="topbox l">
        <p className='num'>{dashdata && dashdata.total_users && dashdata.total_users}</p>
        <p className='des'>Total Number of Users</p>
      </div>
      <div className="topbox d">
      <p className='num'>{dashdata && dashdata.processed_claims && dashdata.processed_claims}</p>
        <p className='des'>Processed Claim</p>
      </div>
      <div className="topbox l">
      <p className='num'>{dashdata && dashdata.total_claims && dashdata.total_claims}</p>
        <p className='des'>Total Claim</p>
      </div>
      <div className="topbox d">
      <p className='num'>{dashdata && dashdata.accepted_claims && dashdata.accepted_claims}</p>
        <p className='des'>Accepted Claims</p>
      </div>
      <div className="topbox l">
      <p className='num'>{dashdata && dashdata.rejected_claims && dashdata.rejected_claims}</p>
        <p className='des'>Total Claims Rejected</p>
      </div>
    </div>
    <div className="charts">
        <div className="chartbox">
            <div className="chartjstop">
                <p className='chartname'>Fund Category</p>
                <select
                className='label'
                style={{}}>
                   <option value="someOption">--select--</option>
    
                     <option value='weekly'>weekly</option>
                    
            </select>
            </div>
            <div className="chart" style={{height:'217px',width:'300px',marginLeft:'60px'}}><Doughchart /></div>
            
        </div>
        <div className="chartbox">
        <div className="chartjstop">
                <p className='chartname'>Fund Reports</p>
                <select
                className='label'
                style={{}}>
                   <option value="someOption">--select--</option>
    
                     <option value='weekly'>weekly</option>
                    
            </select>
            </div>
            <div className="chart" style={{height:'217px',width:'300px',marginLeft:'60px'}}><Doughchart /></div>
        </div>
        <div className="chartbox">
        <div className="chartjstop">
                <p className='chartname'>Fund Analysis</p>
                <select
                className='label'
                style={{}}>
                   <option value="someOption">--select--</option>
    
                     <option value='weekly'>weekly</option>
                    
            </select>
            </div>
            <div className="chart" style={{height:'217px',width:'300px',marginLeft:'60px'}}><Doughchart /></div>
        </div>
    </div>
    <div className="bot">
        <p className="recent">Recently Created Claim</p>
        <div className="recentfund">
        {
                recent && recent.map((item,index)=>{
                    return(
                        <div className="store">
                <div  className='cardtop inpro'>
                    <div className="ggname">
                        <p className='fundname'>{item.claim_id}</p>
                        <p className='created'>{item.claim_amount}</p>
                    </div>
                    <div className="download"></div>
                </div>
                <div className="cardbottom">
                    <p className="description">{item.medical_report_text}</p>
                    <div className='action'>
                        {/* <button className="actionbutton">Edit</button> */}
                        <button className="actionbutton" onClick={()=>navigate(`/info/${item.claim_id}`)}>Info</button>
                    </div>
                </div>
            </div>
                    )

                })
            }
        
        </div>
    </div>
  </>
  )
}

export default Adminhome
