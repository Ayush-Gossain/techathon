import React,{useState} from 'react'
import '../Styles/Register.css'

const Register = () => {
    const [formData, setFormData] = useState({
        firstName: '',
        lastName: '',
        email: '',
        password: '',
        dob: '',
      });



      const newuser = async(e) =>{
        e.preventDefault();
        
        // const thisform = new FormData()
        // thisform.append('first',formData.firstName)
        // thisform.append('last',formData.lastName)
        // thisform.append('email',formData.email)
        // thisform.append('password',formData.password)
        // thisform.append('dob',formData.dob)
        console.log('first',formData.firstName);
        try {
          await fetch(`http://127.0.0.1:5000/register`,{
            method:"post",
            headers:{
                "Content-Type":"application/json"
            },
              body:JSON.stringify({
                
                first:formData.firstName,
                last:formData.lastName,
                email:formData.email,
                password:formData.password,
                dob:formData.dob
                
        
      
            })
            
            }).then(res=>res.json())
            .then(data=>{
              
                console.log(data)
                
               
            }).catch(err=>{
              console.log(err)
            })
          
        } catch (error) {
          alert('error',error)
          
        }
      }
    
      const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevState => ({
          ...prevState,
          [name]: value
        }));
      };
    
      const handleSubmit = (e) => {
        e.preventDefault();
        console.log('Registration Data:', formData);
      };
    
      return (
        <form className="registerForm" >
          <h2 className="title">Create Account</h2>
          <p className="subtitle">Please fill in the details</p>
          
          <div className="inputGroup">
            <input 
              type="text" 
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              required 
            />
            <label>First Name</label>
          </div>

          <div className="inputGroup">
            <input 
              type="text" 
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              required 
            />
            <label>Last Name</label>
          </div>
          
          <div className="inputGroup">
            <input 
              type="email" 
              name="email"
              value={formData.email}
              onChange={handleChange}
              required 
            />
            <label>Email</label>
          </div>
          
          <div className="inputGroup">
            <input 
              type="password" 
              name="password"
              value={formData.password}
              onChange={handleChange}
              required 
            />
            <label>Password</label>
          </div>
          
          <div className="inputGroup">
            <input 
              type="date" 
              name="dob"
              value={formData.dob}
        
              onChange={handleChange}
              required 
            />
            {/* <label>Date of Birth</label> */}
          </div>
          
          <button className="submitButton" type="button" onClick={newuser}>Register</button>
          
          <div className="toggleForm">
            Already have an account? 
            <span>Login</span>
          </div>
        </form>
      );
}

export default Register
