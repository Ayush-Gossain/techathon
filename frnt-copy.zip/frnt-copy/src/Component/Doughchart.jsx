import React from 'react'
import { Doughnut } from 'react-chartjs-2';
import {Chart, ArcElement, Tooltip, Legend} from 'chart.js'
Chart.register(ArcElement, Tooltip, Legend);
// import '../styles/Dough.css'

const Doughchart = () => {
    const data = {
      labels: ['Red', 'Blue', 'Yellow', 'Green'],
      datasets: [
        {
          label: '# of Votes',
          data: [12, 19, 3, 5],
          backgroundColor: [
            '#EDDC95',
            '#A9C5DA',
            '#A1E3CB',
            '#B1E3FF',
          ],

          hoverOffset: 4
        },
      ],
    };

    const options = {
        responsive:true,
        plugins: {
            legend: {
                display: true,
                position:"right",

                labels: {
                    boxwidth:20,
                    padding:20
                }
            }
        },
        layout:{
            padding:{
                right:20,
                top:0,
                bottom:0,
                left:0
            }
        },
        maintainAspectRatio:false,
        tooltip:{
            enabled:true
        }
        
      };

    
  
    return <Doughnut  data={data} options={options} />;
  };

export default Doughchart
