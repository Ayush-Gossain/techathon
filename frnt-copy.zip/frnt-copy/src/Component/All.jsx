// import React from 'react'
import React,{useEffect,useState} from 'react'
import '../Styles/All.css'
import {useNavigate} from 'react-router-dom'

import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import Tooltip from '@mui/material/Tooltip';
import Snackbar from '@mui/material/Snackbar';
import Alert from '@mui/material/Alert';


const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
  }

const All = () => {
    const navigate = useNavigate()
    const [maindata,setmaindata] = useState([])
    const [showdata,setshowdata] = useState([])


    const [open, setOpen] = React.useState(false);
      const [msg,setMsg] = useState('')
      const [alert,setAlert] = useState('')
      const [openBackdrop, setOpenBackdrop] = React.useState(false);

    const handleSortChange = (e) => {
        const selectedColor = e.target.value;
        if (selectedColor === 'all') {
            setshowdata(maindata);
        } else {
          setshowdata(maindata.filter(item => item.status === selectedColor));
        }
      };

    const type = async() =>{
        setOpenBackdrop(true)
        console.log('type called');
        try {
          await fetch('http://127.0.0.1:5000/get_claims',{
            method:"get",
            // headers:{
            //   'Authorization': `Bearer ${token}`
            // }
            }).then(res=>res.json())
            .then(data=>{
              
                console.log(data)
                setmaindata(data)
                setshowdata(data)
                setAlert('success')
                setMsg('success')
                setOpenBackdrop(false)
               
            }).catch(err=>{
              console.log(err)
              setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
            })
          
        } catch (error) {
          alert('error',error)
          setAlert('error')
                setMsg('error')
                setOpenBackdrop(false)
          
        }
      }


      useEffect(()=>{
        type()
      },[])



    
  return (
    <>

<Backdrop
        sx={{ color: '#fff', zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={openBackdrop}
        // onClick={handleClose}
      >
        <CircularProgress color="inherit" />
      </Backdrop>


      <Snackbar anchorOrigin={{ vertical: 'top', horizontal: 'right' }} open={open} autoHideDuration={5000} onClose={handleClose}>
        <Alert
          onClose={handleClose}
          severity={alert}
          variant="filled"
          sx={{ width: '100%' }}
        >
          {msg}
        </Alert>
      </Snackbar>




    <div className="whole">
    <div className="ggright">
        <div className="ggtitle">
            <p>All Claims</p>
            <div >
                <select className='sort' onChange={handleSortChange}>
                    <option value="all">--All--</option>
                    <option value="Approved">Approved</option>
                    <option value="Rejected">Rejected</option>
                    <option value="unknown">Inprogress</option>
                </select>
            </div>
        </div>
        <div className="cards">
            {
                showdata && showdata.map((item,index)=>{
                    return(
                        <div className="store">
                <div  className={item.status == 'Rejected'?'cardtop rej':item.status == 'Approved'?'cardtop app':'cardtop inpro'}>
                    <div className="ggname">
                        <p className='fundname'>{item.claim_id}</p>
                        <p className='created'>{item.claim_amount}</p>
                    </div>
                    <div className="download"></div>
                </div>
                <div className="cardbottom">
                    <p className="description">{item.medical_report_text}</p>
                    <div className='action'>
                        {/* <button className="actionbutton">Edit</button> */}
                        <button className="actionbutton" onClick={()=>navigate(`/info/${item.claim_id}`)}>Info</button>
                    </div>
                </div>
            </div>
                    )

                })
            }
            {/* <div className="store">
                <div className="cardtop">
                    <div className="ggname">
                        <p className='fundname'>Appolo</p>
                        <p className='created'>Created By:113246 643</p>
                    </div>
                    <div className="download"></div>
                </div>
                <div className="cardbottom">
                    <p className="description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    <div className='action'>
                        <button className="actionbutton">Edit</button>
                        <button className="actionbutton" onClick={()=>navigate('/chat')}>Chat</button>
                    </div>
                </div>
            </div>
            <div className="store">
                <div className="cardtop">
                    <div className="ggname">
                        <p className='fundname'>Appolo</p>
                        <p className='created'>Created By:113246 643</p>
                    </div>
                    <div className="download"></div>
                </div>
                <div className="cardbottom">
                    <p className="description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    <div className='action'>
                        <button className="actionbutton">Edit</button>
                        <button className="actionbutton">Chat</button>
                    </div>
                </div>
            </div>
            <div className="store">
                <div className="cardtop">
                    <div className="ggname">
                        <p className='fundname'>Appolo</p>
                        <p className='created'>Created By:113246 643</p>
                    </div>
                    <div className="download"></div>
                </div>
                <div className="cardbottom">
                    <p className="description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    <div className='action'>
                        <button className="actionbutton">Edit</button>
                        <button className="actionbutton">Chat</button>
                    </div>
                </div>
            </div>
            <div className="store">
                <div className="cardtop">
                    <div className="ggname">
                        <p className='fundname'>Appolo</p>
                        <p className='created'>Created By:113246 643</p>
                    </div>
                    <div className="download"></div>
                </div>
                <div className="cardbottom">
                    <p className="description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    <div className='action'>
                        <button className="actionbutton">Edit</button>
                        <button className="actionbutton">Chat</button>
                    </div>
                </div>
            </div>
            <div className="store">
                <div className="cardtop">
                    <div className="ggname">
                        <p className='fundname'>Appolo</p>
                        <p className='created'>Created By:113246 643</p>
                    </div>
                    <div className="download"></div>
                </div>
                <div className="cardbottom">
                    <p className="description">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                    <div className='action'>
                        <button className="actionbutton">Edit</button>
                        <button className="actionbutton">Chat</button>
                    </div>
                </div>
            </div> */}
            
            
        </div>
    </div>
    </div>
    
    </>
  )
}

export default All
