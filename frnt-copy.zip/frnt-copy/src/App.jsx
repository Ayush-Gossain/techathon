import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import {BrowserRouter,Router,Route,Routes,useLocation, Navigate} from 'react-router-dom'
import './App.css'
import Navbar from './Component/Navbar'
import Clienthome from './Component/Clienthome'
import Adminhome from './Component/Adminhome'
import Chat from './Component/Chat'
import Info from './Component/Info'
import All from './Component/All'
import Login from './Component/Login'
import Register from './Component/Register'
import Protectedroute from './Component/Protectedroute'
import Workflow from './Component/Workflow'

function App() {
  const isloggedin = window.localStorage.getItem('isloggedin')
  const usertype = window.localStorage.getItem('type')
  // const location = useLocation();
  // const [path,setPath] = useState(true)

  // if (location.pathname === '/login' || location.pathname === '/reg') {
  //   setPath(false)
  // }
  

  return (
    <BrowserRouter>
    {/* <Router> */}
  <Navbar isloggedin={isloggedin} usertype={usertype} />
    <Routes>
    <Route path="/login" element={<Login />}/>
    <Route path="/reg" element={<Register />}/>
    <Route path="/client/:policy_id" element={<Clienthome />}/>
    <Route path="/admin" element={<Adminhome />}/>
          <Route path="/info/:claim_id" element={<Info />}/>
          <Route path="/report" element={<All />}/>
          <Route path="/workflow" element={<Workflow />}/>

      {/* {!isloggedin && (
        <>
        <Route path="/" element={<Login />}/>
        <Route path="/login" element={<Login />}/>
        <Route path="/reg" element={<Register />}/>
        
        </>
      )} */}
    


    {/* protected */}
    {/* <Route element={<Protectedroute/>}>
      <Route path="/login" element={<Navigate to="/"/>}/>
      <Route path="/reg" element={<Navigate to="/"/>}/>

      { isloggedin && usertype =='user'?(
          <>
          <Route path="/login" element={<Navigate to="/"/>}/>
          <Route path="/" element={<Navigate to="/client"/>}/>
          <Route path="/client" element={<Clienthome />}/>
          
          </>
          
        ):isloggedin && usertype =='approver'?(<>
        <Route path="/login" element={<Navigate to="/"/>}/>
        <Route path="/" element={<Navigate to="/admin"/>}/>
          
          <Route path="/admin" element={<Adminhome />}/>
          <Route path="/info/:claim_id" element={<Info />}/>
          <Route path="/report" element={<All />}/>
        </>)
        :isloggedin&&(<>
        <Route path="/login" element={<Navigate to="/"/>}/>
        <Route path="/" element={<Navigate to="/workflow"/>}/>
          <Route path="/workflow" element={<Clienthome />}/>
          
        </>)
      }


      
    </Route> */}
    <Route path="/about"/>
    {/* <Route path="*" element={<Navigate to="/login"/>}/> */}
    
    </Routes>
    {/* </Router> */}
    {/* <Footer/> */}
    </BrowserRouter>
  )
}

export default App
